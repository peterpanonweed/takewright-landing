@echo off
rem ---------------------------------------------------------------
rem  TAKEWRITE - Synchronbuecher am Bild schreiben
rem
rem  Fragt, an welchem Projekt gearbeitet wird, und startet es.
rem  Jedes Projekt hat einen eigenen Port und damit einen eigenen
rem  Arbeitsstand - zwei Filme koennen gleichzeitig offen sein.
rem
rem  chcp 65001 stellt die Konsole auf UTF-8, sonst zerbroeseln
rem  die Umlaute in der Projektliste.
rem ---------------------------------------------------------------
title Takewrite
setlocal
chcp 65001 >nul

rem  Die mitgelieferte Laufzeit hat Vorrang. Faellt sie weg, wird die des
rem  Entwicklers genommen, zuletzt ein Python aus dem Systempfad.
set "PY=%~dp0Laufzeit\python.exe"
if not exist "%PY%" set "PY=G:\Python314\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" "%~dp0Werkzeuge\starter.py"
if errorlevel 1 pause
exit
