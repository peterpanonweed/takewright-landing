# -*- coding: utf-8 -*-
"""Lizenzen: Rechnerabdruck, Schein pruefen, Schein ausstellen.

    python Werkzeuge/lizenz.py code                     zeigt den Rechnercode
    python Werkzeuge/lizenz.py schluessel               einmalig: Schluesselpaar
    python Werkzeuge/lizenz.py ausstellen CODE "Name" mail@x.de [Monate]

Was hier nicht behauptet wird
-----------------------------
Software, die auf dem Rechner des Kunden laeuft, laesst sich nicht
kopiersicher machen. Der Pruefcode steht in einer Datei, die er oeffnen kann.
Wer ihn entfernen will, entfernt ihn.

Was hier erreicht wird: Der Ordner laesst sich nicht weitergeben. Auf einem
anderen Rechner passt der Schein nicht, und der Server faehrt nicht hoch —
keine Seite, keine App. Wer trotzdem hinein will, muss das Programm umbauen.
Das ist die Schwelle zwischen "einmal kopieren" und "sich damit befassen",
und sie ist genau die, um die es geht.

Der Abdruck
-----------
Vier Kennungen, die eine Windows-Neuinstallation ueberleben: Seriennummer des
Mainboards, des BIOS, die Prozessorkennung und die Systemkennung des Bretts.
Verlangt werden ZWEI davon — aber nie mehr, als der Rechner beim Ausstellen
hergab: Viele Bretter melden gar keine BIOS-Seriennummer, und eine Forderung,
die niemand erfuellen kann, sperrt den zahlenden Kunden aus. Wie viele noetig
sind, steht deshalb im Schein selbst.

Damit ueberlebt der Schein ein neues Windows und einen Plattentausch — ein
neues Mainboard nicht, und das ist richtig so: Das ist ein neuer Rechner.

Nach draussen geht nie eine Seriennummer, nur ihr Hash. Ein Kunde, der mit
vertraulichem Auftragsmaterial arbeitet, soll hoeren koennen: Deine
Hardwaredaten verlassen deinen Rechner nicht.

Die Unterschrift
----------------
Ohne sie schriebe sich jeder sein Ablaufdatum selbst. Signiert wird mit RSA;
geprueft wird mit pow(), das Python von Haus aus kann — es braucht also keine
Zusatzbibliothek im Kundenpaket. Der private Schluessel bleibt hier, im
ausgelieferten Paket steckt nur der oeffentliche.
"""
import base64
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time

HEIM      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCHEIN    = os.path.join(HEIM, "lizenz.dat")
ERSTSTART = os.path.join(HEIM, "Werkzeuge", ".erststart")
GEHEIM    = os.path.join(HEIM, "Werkzeuge", ".lizenzschluessel")
PROFILMARKE = os.path.join(os.environ.get("LOCALAPPDATA")
                           or os.path.expanduser("~"), "Takewrite", "erst")
SCHONFRIST = 14           # Tage, die ohne Schein gearbeitet werden darf
NOETIG     = 2            # so viele Kennungen muessen passen — aber nie mehr,
                          # als beim Ausstellen ueberhaupt lesbar waren

# Der oeffentliche Schluessel. Wird von "lizenz.py schluessel" hier
# hineingeschrieben; bis dahin steht hier nichts und es gilt nur die Schonfrist.
OEFFENTLICH = {"n": 17227409852215047740651317118805649794957206826128931852146911185355795510350889655351197967993551348723554426911328426031420918291786176749389639008891519643107872987015181986367611876368672549946721743706926567184056389887222895917226489013420468238644335211878705584281815341778720531041574645470998486327058077340175254602593753324981186518340104032143309274842191898799741775830705735564499116683843464141612456558273661005186432506950371344126649162899623732760402684219857484885284418980045603708827342462727095051958600745949274467060999383353707891059605751060787133791601947243775231906934949944477139697981, "e": 65537}


# ------------------------------------------------------------ Rechnerabdruck
def _powershell(befehl, zeit=25):
    try:
        e = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                            "-Command", befehl],
                           capture_output=True, text=True, timeout=zeit)
        return e.stdout if e.returncode == 0 else ""
    except Exception:
        return ""


def _roh():
    """Die vier Kennungen, in einem einzigen PowerShell-Aufruf."""
    befehl = ("$b=(Get-CimInstance Win32_BaseBoard).SerialNumber; "
              "$i=(Get-CimInstance Win32_BIOS).SerialNumber; "
              "$c=(Get-CimInstance Win32_Processor | Select-Object -First 1).ProcessorId; "
              "$u=(Get-CimInstance Win32_ComputerSystemProduct).UUID; "
              "[Console]::Out.Write(\"$b`n$i`n$c`n$u\")")
    zeilen = (_powershell(befehl) or "").split("\n")
    while len(zeilen) < 4:
        zeilen.append("")
    return [z.strip() for z in zeilen[:4]]


def _hash(text):
    text = re.sub(r"\s+", "", (text or "")).upper()
    # Serienlose Bretter melden gern "To be filled by O.E.M." — wertlos als
    # Kennung, und ein solcher Wert waere auf tausend Rechnern derselbe.
    if (len(text) < 4 or "TOBEFILLED" in text
            or text in ("NONE", "DEFAULTSTRING", "0", "SYSTEMSERIALNUMBER")
            or set(text) <= set("0-") or set(text) <= set("F-")):
        return ""
    return hashlib.sha256(("takewrite:" + text).encode("utf-8")).hexdigest()[:24]


def abdruck():
    """Die vier Hashes. Leere Eintraege zaehlen als 'nicht vorhanden'."""
    return [h for h in (_hash(x) for x in _roh())]


def code(hashes=None):
    """Der kurze Code, den der Kunde abtippt: TW-XXXX-XXXX-XXXX."""
    h = hashes if hashes is not None else abdruck()
    roh = hashlib.sha256(("|".join(h)).encode("utf-8")).digest()
    b = base64.b32encode(roh).decode("ascii").replace("=", "")[:12]
    return "TW-" + b[0:4] + "-" + b[4:8] + "-" + b[8:12]


def passt(schein_hashes, jetzt=None):
    """Wie viele der drei Kennungen stimmen ueberein."""
    jetzt = jetzt if jetzt is not None else abdruck()
    treffer = 0
    for h in schein_hashes:
        if h and h in jetzt:
            treffer += 1
    return treffer


# ------------------------------------------------------------- Unterschrift
def _inhalt(d):
    """Die zu unterschreibende Fassung — Reihenfolge fest, sonst waere die
       Unterschrift von der Laune des Serialisierers abhaengig."""
    ohne = {k: v for k, v in d.items() if k != "sig"}
    return json.dumps(ohne, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def _fingerprint(roh):
    return int.from_bytes(hashlib.sha256(roh).digest(), "big")


def unterschreiben(d, geheim):
    z = _fingerprint(_inhalt(d))
    return format(pow(z, geheim["d"], geheim["n"]), "x")


def unterschrift_gueltig(d):
    if not OEFFENTLICH.get("n"):
        return False
    try:
        s = int(d.get("sig", ""), 16)
    except (ValueError, TypeError):
        return False
    return pow(s, OEFFENTLICH["e"], OEFFENTLICH["n"]) == _fingerprint(_inhalt(d))


# ------------------------------------------------------------------ Pruefung
def _heute():
    return time.strftime("%Y-%m-%d")


def schein_lesen():
    try:
        with io.open(SCHEIN, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _marke_lesen(pfad):
    try:
        with io.open(pfad, encoding="utf-8") as f:
            t = f.read().strip()[:10]
        return t if re.match(r"^\d{4}-\d{2}-\d{2}$", t) else None
    except OSError:
        return None


def _marke_schreiben(pfad, t):
    try:
        os.makedirs(os.path.dirname(pfad), exist_ok=True)
        io.open(pfad, "w", encoding="utf-8").write(t)
    except OSError:
        pass


def erststart_datum():
    """Wann hier zum ersten Mal gearbeitet wurde.

    Die Marke liegt an zwei Stellen: im Programmordner und im Benutzerprofil.
    Eine Marke im Programmordner allein waere wertlos — wer sie loescht, haette
    wieder vierzehn Tage, und das beliebig oft. Gezaehlt wird ab dem FRUEHEREN
    der beiden Daten; ein neuer Ordner mit frischer Marke erbt so das Datum aus
    dem Profil. Wer beide findet und loescht, hat sich damit befasst — und
    genau da endet, was eine Schonfrist leisten kann."""
    kandidaten = [x for x in (_marke_lesen(ERSTSTART), _marke_lesen(PROFILMARKE)) if x]
    t = min(kandidaten) if kandidaten else _heute()
    if _marke_lesen(ERSTSTART) != t:
        _marke_schreiben(ERSTSTART, t)
    if _marke_lesen(PROFILMARKE) != t:
        _marke_schreiben(PROFILMARKE, t)
    return t


def _tage_zwischen(a, b):
    try:
        ta = time.mktime(time.strptime(a, "%Y-%m-%d"))
        tb = time.mktime(time.strptime(b, "%Y-%m-%d"))
        return int(round((tb - ta) / 86400.0))
    except ValueError:
        return 0


def stand():
    """Was gilt gerade? Gibt zurueck:
         {"darf": bool, "art": "schein"|"schonfrist"|"abgelaufen"|"fremd",
          "rest": Tage, "name": str, "bis": str, "code": str}"""
    jetzt = abdruck()
    d = schein_lesen()
    if d and unterschrift_gueltig(d):
        # Wie viele Treffer noetig sind, stand beim Ausstellen fest: nie mehr,
        # als der Rechner damals ueberhaupt hergab. Auf einem Brett, das nur eine
        # Kennung meldet, waere "zwei von vieren" sonst von Anfang an unerfuellbar.
        noetig = int(d.get("noetig") or NOETIG)
        treffer = passt(d.get("rechner") or [], jetzt)
        if treffer < noetig:
            return {"darf": False, "art": "fremd", "rest": 0,
                    "name": d.get("name", ""), "bis": d.get("bis", ""),
                    "code": code(jetzt), "treffer": treffer}
        rest = _tage_zwischen(_heute(), d.get("bis", "1970-01-01"))
        return {"darf": rest >= 0, "art": "schein" if rest >= 0 else "abgelaufen",
                "rest": rest, "name": d.get("name", ""), "bis": d.get("bis", ""),
                "code": code(jetzt), "treffer": treffer}

    erst = erststart_datum()
    verbraucht = _tage_zwischen(erst, _heute())
    # Zurueckgestellte Uhr: Wer vor dem ersten Start liegt, hat gedreht.
    if verbraucht < 0:
        verbraucht = SCHONFRIST
    rest = SCHONFRIST - verbraucht
    return {"darf": rest > 0, "art": "schonfrist" if rest > 0 else "abgelaufen",
            "rest": max(0, rest), "name": "", "bis": "",
            "code": code(jetzt), "treffer": 0}


# --------------------------------------------------------------- Anforderung
# Der kurze Code ist ein Hash ueber alle drei Kennungen — aus ihm laesst sich
# nichts zurueckrechnen. In den Schein muessen aber die drei einzelnen Hashes,
# sonst gaebe es kein "zwei von dreien" und jeder Plattentausch wuerde den
# Schein toeten. Also schickt der Kunde eine Zeile, die sie enthaelt.
def anforderung(hashes=None):
    """Die eine Zeile, die der Kunde in seine Mail kopiert."""
    h = hashes if hashes is not None else abdruck()
    roh = json.dumps({"c": code(h), "h": h}, separators=(",", ":")).encode("utf-8")
    return "TWQ" + base64.urlsafe_b64encode(roh).decode("ascii").rstrip("=")


def anforderung_lesen(text):
    """Zurueck zu {"c": Code, "h": [drei Hashes]}. Wirft bei Unfug."""
    t = re.sub(r"\s+", "", text or "")
    if not t.startswith("TWQ"):
        raise ValueError("Das ist keine Anforderung — sie beginnt mit TWQ.")
    t = t[3:]
    d = json.loads(base64.urlsafe_b64decode(t + "=" * (-len(t) % 4)))
    h = [x for x in d.get("h") or [] if isinstance(x, str)]
    if not [x for x in h if x]:
        raise ValueError("In der Anforderung steht keine einzige Kennung.")
    if d.get("c") != code(h):
        raise ValueError("Code und Kennungen passen nicht zueinander.")
    return {"c": d["c"], "h": h}


# ------------------------------------------------------------- Schluesselpaar
def _prim(bits):
    """Eine Primzahl. Miller-Rabin, weil die Standardbibliothek nichts mitbringt
       und ein Kundenpaket keine Zusatzbibliothek bekommen soll."""
    import secrets
    klein = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    while True:
        n = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if any(n % p == 0 for p in klein):
            continue
        d, r = n - 1, 0
        while d % 2 == 0:
            d //= 2
            r += 1
        for a in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
            x = pow(a, d, n)
            if x in (1, n - 1):
                continue
            for _ in range(r - 1):
                x = x * x % n
                if x == n - 1:
                    break
            else:
                break
        else:
            return n


def schluessel_erzeugen(bits=2048):
    """Einmalig. Der private Schluessel bleibt hier und geht in kein Paket;
       der oeffentliche wird oben in diese Datei geschrieben und mit
       ausgeliefert."""
    if os.path.exists(GEHEIM):
        raise SystemExit("Es gibt schon einen Schluessel: %s\n"
                         "Ein zweiter macht alle bisher ausgestellten Scheine "
                         "ungueltig. Wenn das wirklich gewollt ist, die Datei "
                         "von Hand wegraeumen." % GEHEIM)
    while True:
        p, q = _prim(bits // 2), _prim(bits // 2)
        if p == q:
            continue
        n, phi = p * q, (p - 1) * (q - 1)
        e = 65537
        if phi % e == 0:      # e muss teilerfremd zu phi sein, nicht Teiler
            continue
        break
    d = pow(e, -1, phi)
    io.open(GEHEIM, "w", encoding="utf-8").write(
        json.dumps({"n": n, "e": e, "d": d}))
    try:                                    # nur der Besitzer darf lesen
        os.chmod(GEHEIM, 0o600)
    except OSError:
        pass

    quelle = os.path.abspath(__file__)
    s = io.open(quelle, encoding="utf-8").read()
    neu = 'OEFFENTLICH = {"n": %d, "e": %d}' % (n, e)
    s2 = re.sub(r'^OEFFENTLICH = \{.*\}$', neu, s, count=1, flags=re.M)
    if s2 == s:
        raise SystemExit("Konnte den oeffentlichen Schluessel nicht eintragen.")
    io.open(quelle, "w", encoding="utf-8", newline="").write(s2)
    return n, e


def geheim_lesen():
    try:
        return json.load(io.open(GEHEIM, encoding="utf-8"))
    except (OSError, ValueError):
        raise SystemExit("Kein privater Schluessel. Einmalig anlegen:\n"
                         "    python Werkzeuge/lizenz.py schluessel")


# --------------------------------------------------------------- Ausstellen
def _plus_monate(monate):
    j, m, t = [int(x) for x in _heute().split("-")]
    m += monate
    j += (m - 1) // 12
    m = (m - 1) % 12 + 1
    t = min(t, [31, 29 if (j % 4 == 0 and j % 100) or j % 400 == 0 else 28,
                31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1])
    return "%04d-%02d-%02d" % (j, m, t)


def ausstellen(anfrage, name, mail, monate=12):
    """Aus der Anforderung des Kunden einen unterschriebenen Schein machen."""
    a = anforderung_lesen(anfrage)
    lesbar = len([x for x in a["h"] if x])
    d = {"name": name, "mail": mail, "code": a["c"], "rechner": a["h"],
         "noetig": min(NOETIG, lesbar),
         "ab": _heute(), "bis": _plus_monate(monate), "art": "jahr"}
    d["sig"] = unterschreiben(d, geheim_lesen())
    return d


# --------------------------------------------------------------------- CLI
def main(argv):
    was = (argv[1] if len(argv) > 1 else "stand").lower()

    if was == "stand":
        s = stand()
        print("Rechnercode:   %s" % s["code"])
        roh = abdruck()
        print("Kennungen:     %d von %d lesbar"
              % (len([x for x in roh if x]), len(roh)))
        print("Zustand:       %s" % s["art"])
        if s["art"] == "schein":
            print("Ausgestellt:   %s, gueltig bis %s (%d Tage)"
                  % (s["name"], s["bis"], s["rest"]))
        elif s["art"] == "schonfrist":
            print("Schonfrist:    noch %d von %d Tagen" % (s["rest"], SCHONFRIST))
        print("Darf laufen:   %s" % ("ja" if s["darf"] else "NEIN"))
        return 0

    if was == "code":
        print(code())
        return 0

    if was == "anforderung":
        print(anforderung())
        return 0

    if was == "schluessel":
        n, e = schluessel_erzeugen()
        print("Schluesselpaar angelegt.")
        print("  privat:      %s   <- niemals ausliefern, niemals in Git" % GEHEIM)
        print("  oeffentlich: in lizenz.py eingetragen (%d Bit)" % n.bit_length())
        return 0

    if was == "ausstellen":
        if len(argv) < 5:
            print('Aufruf: lizenz.py ausstellen TWQ... "Name" mail@x.de [Monate]')
            return 2
        monate = int(argv[5]) if len(argv) > 5 else 12
        d = ausstellen(argv[2], argv[3], argv[4], monate)
        ordner = os.path.join(HEIM, "Lizenzen")
        os.makedirs(ordner, exist_ok=True)
        ziel = os.path.join(ordner, "lizenz-%s.dat" % d["code"].replace("-", ""))
        io.open(ziel, "w", encoding="utf-8", newline="").write(
            json.dumps(d, ensure_ascii=False, indent=1))
        print("Schein fuer %s, gueltig bis %s" % (d["name"], d["bis"]))
        print(ziel)
        print("\nDem Kunden schicken; er legt sie als lizenz.dat neben")
        print("'Takewrite starten.bat'.")
        return 0

    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
