# -*- coding: utf-8 -*-
"""Der Takewrite-Server — liefert die App aus und sichert den Arbeitsstand.

Der eingebaute Webserver von Python kann nur ausliefern. Dieser hier nimmt
zusaetzlich den Arbeitsstand entgegen und legt ihn als Datei in den
Projektordner. Das ist der Unterschied zwischen "der Stand liegt im Browser"
und "der Stand liegt auf der Festplatte":

    takewrite-stand.json                  der aktuelle Stand
    Sicherungen/stand-JJJJ-MM-TT.json     ein Stand je Arbeitstag

Kein Dialog, keine Berechtigung, kein Vergessen. Wird der Browserspeicher
geleert, holt sich die App den Stand beim naechsten Oeffnen aus der Datei.

    python Werkzeuge/server.py <Port> <Ordner>
"""
import io, json, os, shutil, sys, time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace", line_buffering=True)

STAND_DATEI = "takewrite-stand.json"
SICHERUNGEN = "Sicherungen"
TAGESABSTAND = 600          # hoechstens alle zehn Minuten eine Tageskopie


class Takewrite(SimpleHTTPRequestHandler):
    ordner = "."

    def __init__(self, *a, **k):
        super().__init__(*a, directory=Takewrite.ordner, **k)

    # --- Was der Browser schickt ---
    def do_POST(self):
        weg = self.path.split("?")[0].rstrip("/")
        if weg not in ("/stand", "/punkt"):
            self.send_error(404, "Nur /stand und /punkt nehmen etwas entgegen")
            return
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
            if laenge <= 0 or laenge > 64 * 1024 * 1024:
                raise ValueError("unglaubwuerdige Laenge")
            roh = self.rfile.read(laenge)
            d = json.loads(roh.decode("utf-8"))       # muss lesbar sein
            if not isinstance(d, dict) or "zeilen" not in d:
                raise ValueError("kein Arbeitsstand")
        except Exception as e:
            self.send_error(400, "Nicht angenommen: %s" % e)
            return

        try:
            name = self.punkt_setzen(roh) if weg == "/punkt" else self.schreiben(roh)
        except Exception as e:
            self.send_error(500, "Konnte nicht schreiben: %s" % e)
            return

        antwort = json.dumps({"ok": True, "zeilen": len(d.get("zeilen") or []),
                              "name": name}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(antwort)))
        self.end_headers()
        self.wfile.write(antwort)

    def schreiben(self, roh):
        ziel = os.path.join(Takewrite.ordner, STAND_DATEI)
        # Erst danebenschreiben, dann umbenennen: ein Absturz mittendrin
        # darf niemals eine halbe Datei hinterlassen.
        vorlaeufig = ziel + ".neu"
        with open(vorlaeufig, "wb") as f:
            f.write(roh)
            f.flush()
            os.fsync(f.fileno())
        os.replace(vorlaeufig, ziel)

        # Tageskopie — damit man auch auf gestern zurueck kann
        tag = time.strftime("%Y-%m-%d")
        ordner = os.path.join(Takewrite.ordner, SICHERUNGEN)
        os.makedirs(ordner, exist_ok=True)
        kopie = os.path.join(ordner, "stand-%s.json" % tag)
        if (not os.path.exists(kopie)
                or time.time() - os.path.getmtime(kopie) > TAGESABSTAND):
            shutil.copy2(ziel, kopie)
        return STAND_DATEI

    def punkt_setzen(self, roh):
        """Ein Sicherungspunkt von Hand — traegt Datum und Uhrzeit und wird
           nie ueberschrieben. Das ist der Stand, auf den man zurueck kann."""
        ordner = os.path.join(Takewrite.ordner, SICHERUNGEN)
        os.makedirs(ordner, exist_ok=True)
        name = "punkt-%s.json" % time.strftime("%Y-%m-%d-%H%M%S")
        ziel = os.path.join(ordner, name)
        with open(ziel, "wb") as f:
            f.write(roh); f.flush(); os.fsync(f.fileno())
        self.schreiben(roh)                      # der laufende Stand zieht mit
        print("%s  Sicherungspunkt: %s" % (time.strftime("%H:%M:%S"), name))
        return name

    # --- Die vorhandenen Sicherungen aufzaehlen ---
    def do_GET(self):
        if self.path.split("?")[0].rstrip("/") == "/sicherungen":
            self.liste_schicken()
            return
        super().do_GET()

    def liste_schicken(self):
        ordner = os.path.join(Takewrite.ordner, SICHERUNGEN)
        aus = []
        if os.path.isdir(ordner):
            for name in sorted(os.listdir(ordner), reverse=True):
                if not name.endswith(".json"):
                    continue
                p = os.path.join(ordner, name)
                eintrag = {"name": name, "groesse": os.path.getsize(p),
                           "zeit": int(os.path.getmtime(p) * 1000)}
                try:
                    d = json.load(io.open(p, encoding="utf-8"))
                    z = [x for x in (d.get("zeilen") or []) if not x.get("d")]
                    eintrag["rollen"] = len({(x.get("r") or "").strip()
                                             for x in z if (x.get("r") or "").strip()})
                    eintrag["mitRolle"] = sum(1 for x in z if (x.get("r") or "").strip())
                    eintrag["gesetzt"] = sum(1 for x in z if x.get("g"))
                    eintrag["titel"] = (d.get("kopf") or {}).get("Titel", "")
                    eintrag["stand"] = d.get("stand") or 0
                except Exception:
                    eintrag["fehler"] = True
                aus.append(eintrag)
        roh = json.dumps({"sicherungen": aus}, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(roh)))
        self.end_headers()
        self.wfile.write(roh)

    def end_headers(self):
        # Der Arbeitsstand darf nie aus dem Zwischenspeicher kommen
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, format, *args):
        # Nur Fehler und Sicherungen melden, nicht jede Bilddatei
        if args and str(args[0]).startswith(("POST", "GET /stand")):
            sys.stdout.write("%s  %s\n" % (time.strftime("%H:%M:%S"), args[0]))


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8794
    Takewrite.ordner = sys.argv[2] if len(sys.argv) > 2 else os.getcwd()
    print("Takewrite-Server")
    print("  Ordner: %s" % Takewrite.ordner)
    print("  Adresse: http://localhost:%d/Takewright.html" % port)
    print("  Arbeitsstand: %s  (+ Tageskopien in %s\\)" % (STAND_DATEI, SICHERUNGEN))
    print("  Dieses Fenster schliessen beendet das Projekt.")
    print()
    ThreadingHTTPServer(("127.0.0.1", port), Takewrite).serve_forever()


if __name__ == "__main__":
    main()
