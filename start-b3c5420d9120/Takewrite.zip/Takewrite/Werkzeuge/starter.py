# -*- coding: utf-8 -*-
"""Takewrite starten — mit Projektauswahl.

Jedes Projekt bekommt einen eigenen Port. Das ist nicht nur Ordnung: Der
Browser trennt seinen Speicher nach Herkunft (Adresse **samt Port**), also hat
jedes Projekt damit von selbst seinen eigenen Arbeitsstand. Zwei Filme koennen
gleichzeitig offen sein, ohne sich ins Gehege zu kommen.

Die Projekte stehen in Projekte.txt:

    Der lange Sommer | D:\\Filme\\Der lange Sommer

Erste Zeile = Port 8794, zweite = 8795, und so weiter. Die Reihenfolge darf
darum spaeter nicht mehr geaendert werden — sonst sucht ein Projekt seinen
Stand am falschen Port. Neue Projekte immer unten anhaengen.
"""
import io, json, os, shutil, socket, subprocess, sys, webbrowser

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace", line_buffering=True)

HEIM      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LISTE     = os.path.join(HEIM, "Projekte.txt")
ALTE_DATEI = os.path.join(HEIM, "Projektordner.txt")
PROGRAMM  = os.path.join(HEIM, "Takewright.html")
PORT0     = 8794


# ---------------------------------------------------------------- Projektliste
def liste_lesen():
    projekte = []
    if os.path.exists(LISTE):
        for z in io.open(LISTE, encoding="utf-8"):
            z = z.strip()
            if not z or z.startswith("#"):
                continue
            name, _, pfad = z.partition("|")
            if pfad.strip():
                projekte.append((name.strip(), pfad.strip()))
    return projekte


def liste_schreiben(projekte):
    with io.open(LISTE, "w", encoding="utf-8", newline="\n") as f:
        f.write("# Die Projekte von Takewrite. Eine Zeile je Film:\n")
        f.write("#     Name | Ordner\n")
        f.write("# Die Reihenfolge bestimmt den Port (erste Zeile 8794, dann 8795 …)\n")
        f.write("# und damit, wo der Arbeitsstand liegt. Nie umsortieren, nur anhaengen.\n\n")
        for name, pfad in projekte:
            f.write("%s | %s\n" % (name, pfad))


def erstanlage():
    """Beim ersten Start aus der alten Projektordner.txt uebernehmen."""
    pfad = None
    if os.path.exists(ALTE_DATEI):
        for z in io.open(ALTE_DATEI, encoding="cp1252", errors="replace"):
            z = z.strip()
            if z and not z.startswith("#"):
                pfad = z
                break
    if not pfad:
        return []
    name = os.path.basename(pfad.rstrip("\\/")) or "Projekt 1"
    liste_schreiben([(name, pfad)])
    print("Projektliste angelegt aus Projektordner.txt: %s" % name)
    return [(name, pfad)]


# ---------------------------------------------------------------- Hilfsmittel
def lauscht(port):
    s = socket.socket()
    s.settimeout(0.4)
    try:
        s.connect(("127.0.0.1", port))
        return True
    except Exception:
        return False
    finally:
        s.close()


def python_pfad():
    """Erst die mitgelieferte Laufzeit, dann die des Entwicklers, dann das System."""
    for kandidat in (os.path.join(HEIM, "Laufzeit", "python.exe"),
                     r"G:\Python314\python.exe"):
        if os.path.exists(kandidat):
            return kandidat
    return sys.executable


def starten(name, pfad, port):
    if not os.path.isdir(pfad):
        print("Diesen Ordner gibt es nicht: %s" % pfad)
        return False

    shutil.copy2(PROGRAMM, os.path.join(pfad, "Takewright.html"))
    # Der Steckbrief liegt beim Film — daran erkennt die App, welches Projekt
    # sie gerade ist, und schreibt den Namen in ihre Kopfzeile.
    io.open(os.path.join(pfad, "projekt.json"), "w", encoding="utf-8", newline="\n").write(
        json.dumps({"name": name, "ordner": pfad, "port": port}, ensure_ascii=False))

    if lauscht(port):
        print("Server läuft bereits auf Port %d." % port)
    else:
        subprocess.Popen(
            ["cmd", "/c", "start",
             "Takewrite-Server: %s  --  dieses Fenster beendet das Projekt" % name,
             "/min", python_pfad(),
             os.path.join(HEIM, "Werkzeuge", "server.py"), str(port), pfad],
            shell=False)
        print("Server gestartet auf Port %d." % port)

    webbrowser.open("http://localhost:%d/Takewright.html" % port)
    return True


# ---------------------------------------------------------------- Bedienung
def neues_projekt(projekte):
    print()
    pfad = input("Ordner des Films (Pfad einfügen): ").strip().strip('"')
    if not pfad:
        return None
    if not os.path.isdir(pfad):
        print("Diesen Ordner gibt es nicht.")
        return None
    for _, p in projekte:
        if os.path.normcase(os.path.abspath(p)) == os.path.normcase(os.path.abspath(pfad)):
            print("Dieser Ordner steht schon in der Liste.")
            return None
    vorschlag = os.path.basename(pfad.rstrip("\\/"))
    name = input("Name des Projekts [%s]: " % vorschlag).strip() or vorschlag
    projekte.append((name, pfad))
    liste_schreiben(projekte)
    print("Angelegt: %s  (Port %d)" % (name, PORT0 + len(projekte) - 1))
    return len(projekte) - 1


# ------------------------------------------------------------- Verknuepfung
"""Eine Verknuepfung mit Symbol, angelegt beim ersten Start.

Eine fertige .lnk ins Paket zu legen geht nicht: Eine Windows-Verknuepfung
speichert den absoluten Zielpfad. Wer in einen eigenen Ordner entpackt
und wer auf den Desktop entpackt, braeuchte verschiedene Dateien. Angelegt wird sie darum
hier, wo die Pfade zur Laufzeit feststehen und immer stimmen.

Gebaut wird sie ueber den WScript.Shell von PowerShell — die mitgelieferte
Laufzeit ist ein nacktes Python ohne pywin32. Schlaegt es fehl, ist das kein
Grund, den Start abzubrechen: Die .bat funktioniert weiterhin.
"""
MARKE = os.path.join(HEIM, "Werkzeuge", ".verknuepfung")


def _ps(text):
    """Ein PowerShell-Zeichenkettenliteral. Pfade koennen Apostrophe enthalten."""
    return "'" + text.replace("'", "''") + "'"


def _powershell(befehl, zeit=25):
    try:
        return subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
             "-Command", befehl],
            capture_output=True, text=True, timeout=zeit)
    except Exception:
        return None


def verknuepfung_bauen(wohin, ziel, symbol, ordner):
    befehl = ("$w = New-Object -ComObject WScript.Shell; "
              "$s = $w.CreateShortcut(%s); "
              "$s.TargetPath = %s; "
              "$s.WorkingDirectory = %s; "
              "$s.IconLocation = %s; "
              "$s.Description = 'Takewrite - Synchronbuecher am Bild schreiben'; "
              "$s.Save()"
              % (_ps(wohin), _ps(ziel), _ps(ordner), _ps(symbol)))
    _powershell(befehl)
    return os.path.exists(wohin)


def desktop_pfad():
    """Nicht ueber %USERPROFILE%: Bei OneDrive liegt der Desktop woanders."""
    e = _powershell("[Environment]::GetFolderPath('Desktop')")
    if not e or not e.stdout:
        return None
    pfad = e.stdout.strip()
    return pfad if pfad and os.path.isdir(pfad) else None


def erstes_einrichten():
    """Laeuft genau einmal — beim ersten Start nach dem Entpacken."""
    if os.path.exists(MARKE):
        return
    bat = os.path.join(HEIM, "Takewrite starten.bat")
    symbol = os.path.join(HEIM, "Symbole", "takewright.ico")
    if not (os.path.exists(bat) and os.path.exists(symbol)):
        return

    print()
    print("  Einmalige Einrichtung")
    im_ordner = os.path.join(HEIM, "Takewrite.lnk")
    if verknuepfung_bauen(im_ordner, bat, symbol, HEIM):
        print("  Verknüpfung angelegt: %s" % im_ordner)
    else:
        print("  (Verknüpfung im Ordner ließ sich nicht anlegen — die .bat tut es auch.)")

    try:
        antwort = input("  Auch eine auf dem Desktop? [J/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return                      # ohne Marke: beim naechsten Mal neu fragen
    if antwort in ("", "j", "ja", "y"):
        d = desktop_pfad()
        if d and verknuepfung_bauen(os.path.join(d, "Takewrite.lnk"), bat, symbol, HEIM):
            print("  Auf dem Desktop angelegt.")
        else:
            print("  (Auf dem Desktop ließ es sich nicht anlegen.)")

    try:
        io.open(MARKE, "w", encoding="utf-8").write("einmalig erledigt")
    except OSError:
        pass


def main():
    if not os.path.exists(PROGRAMM):
        print("Takewright.html fehlt in %s" % HEIM)
        input("Enter zum Schließen ")
        return

    erstes_einrichten()

    projekte = liste_lesen() or erstanlage()

    if not projekte:
        print("Noch kein Projekt eingerichtet.")
        i = neues_projekt([])
        if i is None:
            input("Enter zum Schließen ")
            return
        projekte = liste_lesen()

    # Das Menue kommt auch bei einem einzigen Projekt — sonst waere "N" fuer
    # ein neues nie erreichbar. Enter startet einfach das erste.
    print()
    print("  TAKEWRITE — welches Projekt?")
    print("  " + "-" * 46)
    for i, (name, pfad) in enumerate(projekte):
        port = PORT0 + i
        marke = " ●" if lauscht(port) else "  "
        print("  %s %d)  %-28s  Port %d" % (marke, i + 1, name[:28], port))
    print("     N)  neues Projekt anlegen")
    print("  " + "-" * 46)
    print("     ● = läuft schon")
    print()

    wahl = input("Nummer (Enter = 1): ").strip().lower()
    if wahl in ("n", "neu"):
        i = neues_projekt(projekte)
        if i is None:
            input("Enter zum Schließen ")
            return
        projekte = liste_lesen()
    else:
        try:
            i = int(wahl) - 1 if wahl else 0
        except ValueError:
            i = 0
        if not (0 <= i < len(projekte)):
            i = 0

    name, pfad = projekte[i]
    starten(name, pfad, PORT0 + i)


if __name__ == "__main__":
    main()
