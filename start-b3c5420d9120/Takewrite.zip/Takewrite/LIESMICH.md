# Takewrite

Synchronbücher am Bild schreiben.

## Starten

Desktop-Verknüpfung **Takewrite** — oder `Takewrite starten.bat` hier im Ordner.

Beim allerersten Start legt Takewrite die Verknüpfung selbst an, mit Symbol, und
fragt einmal, ob auch eine auf den Desktop soll. Danach wird nicht mehr gefragt.

Gibt es mehr als ein Projekt, fragt der Starter zuerst, an welchem Film gearbeitet
wird. **N** legt ein neues an: Ordner einfügen, Namen vergeben, fertig.

## Projekte

Jedes Projekt bekommt **seinen eigenen Port** — das erste 8794, das zweite 8795
und so weiter. Das ist nicht nur Ordnung: Der Browser trennt seinen Speicher nach
Adresse **samt Port**. Damit hat jeder Film automatisch seinen eigenen
Arbeitsstand, und zwei Filme können gleichzeitig offen sein, ohne sich zu stören.
Die Kopfzeile zeigt, in welchem Projekt man gerade schreibt.

Die Projekte stehen in `Projekte.txt`:

```
Der lange Sommer | D:\Filme\Der lange Sommer
```

**Die Reihenfolge nie ändern** — sie bestimmt den Port und damit, wo der
Arbeitsstand liegt. Neue Projekte immer unten anhängen.

In jedem Filmordner müssen liegen:

| Datei | wozu |
|---|---|
| die Filmdatei | wird beim Start einmal von Hand ausgewählt |
| eine `.srt` | wird beim Öffnen automatisch geladen |

Der Name ist gleichgültig: Takewrite sieht im Projektordner nach und nimmt die
erste Untertiteldatei, die es findet. Enthält der Name `de` oder `deutsch`, hat
sie Vorrang vor der Originalfassung. Liegen mehrere dort und es erwischt die
falsche, führt der Knopf **Andere Datei…** über der Buchspalte zur richtigen —
er nimmt auch eine schlichte Textdatei mit einer Zeile je Take.

Die Datei `projekt.json` legt der Starter selbst an — nicht von Hand ändern.

## Eine Installation, ein Programm

Der Browser darf aus Sicherheitsgründen nur einen einzigen Ordner sehen — deshalb
läuft je Projekt ein eigener kleiner Server, der genau dessen Ordner zeigt. Das
**Programm** liefert er dabei immer aus dieser Installation aus, nie aus dem
Projektordner. Vorher lagerten dort Kopien, die still veralteten; wer ein altes
Projekt öffnete, arbeitete mit einer alten Fassung.

Der Arbeitsstand liegt im Browser (localStorage), nicht in der Datei. Er hängt
am Dateinamen; wird die Datei umbenannt, holt sich die App beim ersten Start
den jüngsten vorhandenen Stand und führt ihn unter dem neuen Namen weiter.

## Sicherung — der Arbeitsstand liegt auf der Festplatte

**Von selbst:** Beim Schreiben schickt die App jede Änderung an ihren eigenen
Server, und der legt sie als Datei in den Projektordner:

```
takewrite-stand.json                     der laufende Stand
Sicherungen/stand-JJJJ-MM-TT.json        eine Kopie je Arbeitstag
Sicherungen/punkt-JJJJ-MM-TT-HHMMSS.json ein Sicherungspunkt von Hand
```

**Von Hand:** Oben rechts der grüne Knopf **💾 SICHERN**. Er hält den jetzigen
Stand mit Datum und Uhrzeit fest — und **überschreibt nie etwas**. Nach jeder
Arbeitsstrecke einmal drücken, dann gibt es immer einen Punkt zum Zurück.

**Zurückholen:** Der Knopf **Sicherungen…** daneben zeigt alle vorhandenen
Stände mit Datum, Anzahl Rollen und bestätigten Zeiten. Vor dem Zurückholen
wird der jetzige Stand automatisch als Sicherungspunkt festgehalten — man
springt also nie ohne Netz.

Unten im Feld **Ausgabe** zeigt eine Lampe, wohin gesichert wird:

| | |
|---|---|
| **grün** | „gesichert 14:32 · 1308 Zeilen im Projektordner" — alles auf der Platte |
| **orange** | nur im Browser — dann läuft der Takewrite-Server nicht |

Beim Öffnen vergleicht die App Datei und Browserspeicher und nimmt den jüngeren
Stand. Enthält die Datei **weniger Arbeit** (Rollen, bestätigte Zeiten), fragt
sie erst nach — stillschweigend weggenommen wird nie etwas.

Für den Wechsel auf einen anderen Rechner: **Stand als Datei** lädt ihn
herunter, **Stand einlesen…** liest ihn dort wieder ein.

Weitere Netze: Strg+Z / Strg+Y (bis zu 80 Schritte in der Sitzung) und
**Aus DOCX zurückholen** — jeder Export ist zugleich eine Sicherung
(Zeiten dann auf Bild 0).

## Lizenz

Takewrite läuft auf **einem Rechner**. Beim ersten Start beginnt eine Probezeit
von 14 Tagen; danach braucht es einen Schein.

Oben in der Kopfzeile steht während der Probezeit ein Feld mit den verbleibenden
Tagen. Ein Klick darauf zeigt den Rechnercode und eine Zeile, die an
**mail@adamnuemm.de** geht. Zurück kommt eine Datei **lizenz.dat** — die gehört
in denselben Ordner wie `Takewrite starten.bat`, dann läuft es weiter.

In dieser Zeile steht **keine Seriennummer**, nur deren Prüfsumme. Es geht auch
sonst nichts nach draußen: Takewrite spricht mit keinem Server, weder beim
Freischalten noch beim Arbeiten. Wer mit vertraulichem Auftragsmaterial
arbeitet, kann das nachrechnen — der Prüfcode liegt offen in
`Werkzeuge/lizenz.py`.

Der Schein hängt am Mainboard, nicht an der Festplatte: **Ein neues Windows oder
eine neue Platte ändert nichts.** Ein neuer Rechner braucht einen neuen Schein —
der wird umgeschrieben und kostet nichts.

Läuft die Lizenz ab, bleibt **alles Geschriebene liegen**: Bücher, Sicherungen
und Einstellungen stehen unberührt in den Projektordnern. Es startet nur das
Programm nicht mehr.

## Ordner

| | |
|---|---|
| `Takewright.html` | das Programm — eine einzige Datei, Vorlage eingebettet |
| `Takewrite starten.bat` | Starter — legt beim ersten Mal die Verknüpfung an |
| `Projekte.txt` | die Filme, einer je Zeile — Reihenfolge = Port |
| `Vorlage/` | die Studio-Vorlage, aus der die Exporte gebaut werden |
| `Werkzeuge/` | Starter, Auslieferstraße, Demo-Bau, Vorlage einbetten, Domain-Umzug |
| `Marketing/` | Landingpage |
| `Symbole/` | Programmsymbol |
| `Sicherung/` | Fassungen vor größeren Eingriffen |
| `releases/` | eingefrorene Versionen — `1.0` vom 23.08.2026 |

## Vorlage austauschen

Neue `.docx` nach `Vorlage/` legen, in `Werkzeuge/vorlage_einbetten.py` den
Pfad anpassen, Skript laufen lassen, und den Inhalt von `vorlage_eingebettet.js`
in `Takewright.html` an die Stelle von `var VORLAGE = …` setzen.

Das Skript setzt dabei die Seitengröße auf exaktes DIN A4 (11906 × 16838 Twips).
Die gelieferte Vorlage weicht um einen Zehntelmillimeter ab, und Word schreibt
dann „Benutzerdefiniert“ statt „A4“. Es gibt **zwei** Abschnitte in der Vorlage —
beide müssen umgestellt werden.
