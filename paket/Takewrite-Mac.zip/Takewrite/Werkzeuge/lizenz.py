# -*- coding: utf-8 -*-
"""Lizenzen: Rechnerabdruck, Schein pruefen, Schein ausstellen.

    python Werkzeuge/lizenz.py code                     zeigt den Rechnercode
    python Werkzeuge/lizenz.py schluessel               einmalig: Schluesselpaar
    python Werkzeuge/lizenz.py ausstellen CODE "Name" mail@x.de [Monate]
    python Werkzeuge/lizenz.py gutschein "Name" mail@x.de [Monate]
    python Werkzeuge/lizenz.py einloesen TWG...

Was hier nicht behauptet wird
-----------------------------
Software, die auf dem Rechner des Kunden laeuft, laesst sich nicht
kopiersicher machen. Der Pruefcode steht in einer Datei, die er oeffnen kann.
Wer ihn entfernen will, entfernt ihn.

Was hier erreicht wird: Der Ordner laesst sich nicht weitergeben. Auf einem
anderen Rechner passt der Schein nicht, und der Server faehrt nicht hoch —
keine Seite, keine App. Wer trotzdem hinein will, muss das Programm umbauen.
Das ist die Schwelle zwischen "einmal kopieren" und "sich damit befassen",
und sie ist genau die, um die es geht.

Der Abdruck
-----------
Vier Kennungen, die eine Windows-Neuinstallation ueberleben: Seriennummer des
Mainboards, des BIOS, die Prozessorkennung und die Systemkennung des Bretts.
Verlangt werden ZWEI davon — aber nie mehr, als der Rechner beim Ausstellen
hergab: Viele Bretter melden gar keine BIOS-Seriennummer, und eine Forderung,
die niemand erfuellen kann, sperrt den zahlenden Kunden aus. Wie viele noetig
sind, steht deshalb im Schein selbst.

Damit ueberlebt der Schein ein neues Windows und einen Plattentausch — ein
neues Mainboard nicht, und das ist richtig so: Das ist ein neuer Rechner.

Nach draussen geht nie eine Seriennummer, nur ihr Hash. Ein Kunde, der mit
vertraulichem Auftragsmaterial arbeitet, soll hoeren koennen: Deine
Hardwaredaten verlassen deinen Rechner nicht.

Die Unterschrift
----------------
Ohne sie schriebe sich jeder sein Ablaufdatum selbst. Signiert wird mit RSA;
geprueft wird mit pow(), das Python von Haus aus kann — es braucht also keine
Zusatzbibliothek im Kundenpaket. Der private Schluessel bleibt hier, im
ausgelieferten Paket steckt nur der oeffentliche.
"""
import base64
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time

HEIM      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCHEIN    = os.path.join(HEIM, "lizenz.dat")
ERSTSTART = os.path.join(HEIM, "Werkzeuge", ".erststart")
GEHEIM    = os.path.join(HEIM, "Werkzeuge", ".lizenzschluessel")
PROFILMARKE = os.path.join(os.environ.get("LOCALAPPDATA")
                           or os.path.expanduser("~"), "Takewrite", "erst")
# Wohin ein Kunde schreibt. Steht bewusst nur hier: Vorher klebte die Adresse
# im Starter, in der App, im LIESMICH und auf der Kaufseite, und ein Wechsel
# haette geheissen, sie an vier Stellen zu suchen und an einer zu vergessen.
KONTAKT = "support@takewrite.de"

SCHONFRIST = 14           # Tage, die ohne Schein gearbeitet werden darf
NOETIG     = 2            # so viele Kennungen muessen passen — aber nie mehr,
                          # als beim Ausstellen ueberhaupt lesbar waren

# Der oeffentliche Schluessel. Wird von "lizenz.py schluessel" hier
# hineingeschrieben; bis dahin steht hier nichts und es gilt nur die Schonfrist.
OEFFENTLICH = {"n": 17227409852215047740651317118805649794957206826128931852146911185355795510350889655351197967993551348723554426911328426031420918291786176749389639008891519643107872987015181986367611876368672549946721743706926567184056389887222895917226489013420468238644335211878705584281815341778720531041574645470998486327058077340175254602593753324981186518340104032143309274842191898799741775830705735564499116683843464141612456558273661005186432506950371344126649162899623732760402684219857484885284418980045603708827342462727095051958600745949274467060999383353707891059605751060787133791601947243775231906934949944477139697981, "e": 65537}


# ------------------------------------------------------------ Rechnerabdruck
def _powershell(befehl, zeit=25):
    try:
        e = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                            "-Command", befehl],
                           capture_output=True, text=True, timeout=zeit)
        return e.stdout if e.returncode == 0 else ""
    except Exception:
        return ""


def _befehl(args, zeit=20):
    """Ein Systembefehl, dessen Ausgabe uns interessiert. Schlaegt er fehl,
       ist das kein Fehler, sondern eine Kennung weniger."""
    try:
        e = subprocess.run(args, capture_output=True, text=True, timeout=zeit)
        return e.stdout if e.returncode == 0 else ""
    except Exception:
        return ""


def _roh_mac():
    """Dieselbe Idee wie unter Windows, mit den Mitteln des Macs: vier
       Kennungen, von denen zwei stimmen muessen.

       Bewusst NICHT dabei ist die Modellkennung (MacBookPro18,2 o.ae.) — die
       ist auf hunderttausend Geraeten dieselbe und waere als Bindung wertlos.
       Die Hardware-UUID und die Seriennummer stecken im Geraet, die
       MAC-Adresse der ersten Schnittstelle ebenfalls; die Kennung des
       Startvolumens ueberlebt zwar kein Loeschen der Platte, ist aber als
       vierter Halt gut genug."""
    reg = _befehl(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"])
    def aus_ioreg(feld):
        t = re.search(r'"%s"\s*=\s*"([^"]*)"' % feld, reg or "")
        return t.group(1) if t else ""

    uuid = aus_ioreg("IOPlatformUUID")
    seriennummer = aus_ioreg("IOPlatformSerialNumber")

    mac = ""
    t = re.search(r"ether\s+([0-9a-fA-F:]{17})", _befehl(["ifconfig", "en0"]) or "")
    if t:
        mac = "en0:" + t.group(1)

    band = ""
    t = re.search(r"Volume UUID:\s*([0-9A-Fa-f-]{8,})",
                  _befehl(["diskutil", "info", "/"]) or "")
    if t:
        band = "vol:" + t.group(1)

    return [uuid, seriennummer, mac, band, ""]


def _roh():
    """Die vier Hardwarekennungen — plus, nur im Notfall, eine fuenfte."""
    if sys.platform == "darwin":
        return _roh_mac()
    befehl = ("$b=(Get-CimInstance Win32_BaseBoard).SerialNumber; "
              "$i=(Get-CimInstance Win32_BIOS).SerialNumber; "
              "$c=(Get-CimInstance Win32_Processor | Select-Object -First 1).ProcessorId; "
              "$u=(Get-CimInstance Win32_ComputerSystemProduct).UUID; "
              "[Console]::Out.Write(\"$b`n$i`n$c`n$u\")")
    zeilen = (_powershell(befehl) or "").split("\n")
    while len(zeilen) < 4:
        zeilen.append("")
    vier = [z.strip() for z in zeilen[:4]]

    # Notnagel. Wenn weniger als zwei echte Kennungen zu holen sind — ein Brett,
    # das nichts meldet, oder eine Richtlinie, die PowerShell sperrt — gaebe es
    # sonst gar keinen Schein: Der Kunde haette bezahlt und koennte nie
    # freigeschaltet werden. Die Windows-Kennung aus der Registrierung ist
    # schwaecher, sie ueberlebt keine Neuinstallation. Deshalb kommt sie NUR
    # dazu, wenn es ohne sie nicht reicht. Auf einem normalen Rechner bleibt die
    # Bindung damit so hart wie bisher, und eine Platte, die in einen anderen
    # Kasten wandert, traegt den Schein nicht mit.
    if len([x for x in vier if _hash(x)]) >= NOETIG:
        return vier + [""]
    return vier + [_windows_kennung()]


def _windows_kennung():
    """Die MachineGuid. Ohne PowerShell lesbar — deshalb der letzte Ausweg."""
    try:
        import winreg
        pfad = "SOFTWARE" + chr(92) + "Microsoft" + chr(92) + "Cryptography"
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, pfad, 0,
                           winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
        wert = winreg.QueryValueEx(k, "MachineGuid")[0]
        winreg.CloseKey(k)
        return "win:" + str(wert)
    except Exception:
        return ""


def _hash(text):
    text = re.sub(r"\s+", "", (text or "")).upper()
    # Serienlose Bretter melden gern "To be filled by O.E.M." — wertlos als
    # Kennung, und ein solcher Wert waere auf tausend Rechnern derselbe.
    if (len(text) < 4 or "TOBEFILLED" in text
            or text in ("NONE", "DEFAULTSTRING", "0", "SYSTEMSERIALNUMBER")
            or set(text) <= set("0-") or set(text) <= set("F-")):
        return ""
    return hashlib.sha256(("takewrite:" + text).encode("utf-8")).hexdigest()[:24]


def abdruck():
    """Die vier Hashes. Leere Eintraege zaehlen als 'nicht vorhanden'."""
    return [h for h in (_hash(x) for x in _roh())]


def code(hashes=None):
    """Der kurze Code, den der Kunde abtippt: TW-XXXX-XXXX-XXXX."""
    h = hashes if hashes is not None else abdruck()
    # Nur die vorhandenen Kennungen. Zaehlten die leeren mit, verschoebe sich
    # der Code eines Kunden, sobald wir die Liste um eine Kennung erweitern —
    # und er haette ploetzlich einen anderen Code als auf seiner Rechnung.
    roh = hashlib.sha256(("|".join(x for x in h if x)).encode("utf-8")).digest()
    b = base64.b32encode(roh).decode("ascii").replace("=", "")[:12]
    return "TW-" + b[0:4] + "-" + b[4:8] + "-" + b[8:12]


def passt(schein_hashes, jetzt=None):
    """Wie viele der drei Kennungen stimmen ueberein."""
    jetzt = jetzt if jetzt is not None else abdruck()
    treffer = 0
    for h in schein_hashes:
        if h and h in jetzt:
            treffer += 1
    return treffer


# ------------------------------------------------------------- Unterschrift
def _inhalt(d):
    """Die zu unterschreibende Fassung — Reihenfolge fest, sonst waere die
       Unterschrift von der Laune des Serialisierers abhaengig."""
    ohne = {k: v for k, v in d.items() if k != "sig"}
    return json.dumps(ohne, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def _fingerprint(roh):
    return int.from_bytes(hashlib.sha256(roh).digest(), "big")


def unterschreiben(d, geheim):
    z = _fingerprint(_inhalt(d))
    return format(pow(z, geheim["d"], geheim["n"]), "x")


def unterschrift_gueltig(d):
    if not OEFFENTLICH.get("n"):
        return False
    try:
        s = int(d.get("sig", ""), 16)
    except (ValueError, TypeError):
        return False
    return pow(s, OEFFENTLICH["e"], OEFFENTLICH["n"]) == _fingerprint(_inhalt(d))


# ------------------------------------------------------------------ Pruefung
def _heute():
    return time.strftime("%Y-%m-%d")


def schein_lesen():
    try:
        with io.open(SCHEIN, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _marke_lesen(pfad):
    try:
        with io.open(pfad, encoding="utf-8") as f:
            t = f.read().strip()[:10]
        return t if re.match(r"^\d{4}-\d{2}-\d{2}$", t) else None
    except OSError:
        return None


def _marke_schreiben(pfad, t):
    try:
        os.makedirs(os.path.dirname(pfad), exist_ok=True)
        io.open(pfad, "w", encoding="utf-8").write(t)
    except OSError:
        pass


def erststart_datum():
    """Wann hier zum ersten Mal gearbeitet wurde.

    Die Marke liegt an zwei Stellen: im Programmordner und im Benutzerprofil.
    Eine Marke im Programmordner allein waere wertlos — wer sie loescht, haette
    wieder vierzehn Tage, und das beliebig oft. Gezaehlt wird ab dem FRUEHEREN
    der beiden Daten; ein neuer Ordner mit frischer Marke erbt so das Datum aus
    dem Profil. Wer beide findet und loescht, hat sich damit befasst — und
    genau da endet, was eine Schonfrist leisten kann."""
    kandidaten = [x for x in (_marke_lesen(ERSTSTART), _marke_lesen(PROFILMARKE)) if x]
    t = min(kandidaten) if kandidaten else _heute()
    if _marke_lesen(ERSTSTART) != t:
        _marke_schreiben(ERSTSTART, t)
    if _marke_lesen(PROFILMARKE) != t:
        _marke_schreiben(PROFILMARKE, t)
    return t


def _tage_zwischen(a, b):
    try:
        ta = time.mktime(time.strptime(a, "%Y-%m-%d"))
        tb = time.mktime(time.strptime(b, "%Y-%m-%d"))
        return int(round((tb - ta) / 86400.0))
    except ValueError:
        return 0


def stand():
    """Was gilt gerade? Gibt zurueck:
         {"darf": bool, "art": "schein"|"schonfrist"|"abgelaufen"|"fremd",
          "rest": Tage, "name": str, "bis": str, "code": str}"""
    jetzt = abdruck()
    d = schein_lesen()
    if d and d.get("art") == "gutschein":
        g = gutschein_stand(d)
        if g:
            return g
    if d and unterschrift_gueltig(d):
        # Wie viele Treffer noetig sind, stand beim Ausstellen fest: nie mehr,
        # als der Rechner damals ueberhaupt hergab. Auf einem Brett, das nur eine
        # Kennung meldet, waere "zwei von vieren" sonst von Anfang an unerfuellbar.
        noetig = int(d.get("noetig") or NOETIG)
        treffer = passt(d.get("rechner") or [], jetzt)
        if treffer < noetig:
            return {"darf": False, "art": "fremd", "rest": 0,
                    "name": d.get("name", ""), "bis": d.get("bis", ""),
                    "code": code(jetzt), "treffer": treffer}
        rest = _tage_zwischen(_heute(), d.get("bis", "1970-01-01"))
        return {"darf": rest >= 0, "art": "schein" if rest >= 0 else "abgelaufen",
                "rest": rest, "name": d.get("name", ""), "bis": d.get("bis", ""),
                "code": code(jetzt), "treffer": treffer}

    erst = erststart_datum()
    verbraucht = _tage_zwischen(erst, _heute())
    # Zurueckgestellte Uhr: Wer vor dem ersten Start liegt, hat gedreht.
    if verbraucht < 0:
        verbraucht = SCHONFRIST
    rest = SCHONFRIST - verbraucht
    return {"darf": rest > 0, "art": "schonfrist" if rest > 0 else "abgelaufen",
            "rest": max(0, rest), "name": "", "bis": "",
            "code": code(jetzt), "treffer": 0}


# --------------------------------------------------------------- Anforderung
# Der kurze Code ist ein Hash ueber alle drei Kennungen — aus ihm laesst sich
# nichts zurueckrechnen. In den Schein muessen aber die drei einzelnen Hashes,
# sonst gaebe es kein "zwei von dreien" und jeder Plattentausch wuerde den
# Schein toeten. Also schickt der Kunde eine Zeile, die sie enthaelt.
def anforderung(hashes=None):
    """Die eine Zeile, die der Kunde in seine Mail kopiert."""
    h = hashes if hashes is not None else abdruck()
    roh = json.dumps({"c": code(h), "h": h}, separators=(",", ":")).encode("utf-8")
    return "TWQ" + base64.urlsafe_b64encode(roh).decode("ascii").rstrip("=")


def anforderung_lesen(text):
    """Zurueck zu {"c": Code, "h": [drei Hashes]}. Wirft bei Unfug."""
    t = re.sub(r"\s+", "", text or "")
    if not t.startswith("TWQ"):
        raise ValueError("Das ist keine Anforderung — sie beginnt mit TWQ.")
    t = t[3:]
    d = json.loads(base64.urlsafe_b64decode(t + "=" * (-len(t) % 4)))
    h = [x for x in d.get("h") or [] if isinstance(x, str)]
    if not [x for x in h if x]:
        raise ValueError("In der Anforderung steht keine einzige Kennung.")
    if d.get("c") != code(h):
        raise ValueError("Code und Kennungen passen nicht zueinander.")
    return {"c": d["c"], "h": h}


# ------------------------------------------------------------- Schluesselpaar
def _prim(bits):
    """Eine Primzahl. Miller-Rabin, weil die Standardbibliothek nichts mitbringt
       und ein Kundenpaket keine Zusatzbibliothek bekommen soll."""
    import secrets
    klein = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    while True:
        n = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if any(n % p == 0 for p in klein):
            continue
        d, r = n - 1, 0
        while d % 2 == 0:
            d //= 2
            r += 1
        for a in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
            x = pow(a, d, n)
            if x in (1, n - 1):
                continue
            for _ in range(r - 1):
                x = x * x % n
                if x == n - 1:
                    break
            else:
                break
        else:
            return n


def schluessel_erzeugen(bits=2048):
    """Einmalig. Der private Schluessel bleibt hier und geht in kein Paket;
       der oeffentliche wird oben in diese Datei geschrieben und mit
       ausgeliefert."""
    if os.path.exists(GEHEIM):
        raise SystemExit("Es gibt schon einen Schluessel: %s\n"
                         "Ein zweiter macht alle bisher ausgestellten Scheine "
                         "ungueltig. Wenn das wirklich gewollt ist, die Datei "
                         "von Hand wegraeumen." % GEHEIM)
    while True:
        p, q = _prim(bits // 2), _prim(bits // 2)
        if p == q:
            continue
        n, phi = p * q, (p - 1) * (q - 1)
        e = 65537
        if phi % e == 0:      # e muss teilerfremd zu phi sein, nicht Teiler
            continue
        break
    d = pow(e, -1, phi)
    io.open(GEHEIM, "w", encoding="utf-8").write(
        json.dumps({"n": n, "e": e, "d": d}))
    try:                                    # nur der Besitzer darf lesen
        os.chmod(GEHEIM, 0o600)
    except OSError:
        pass

    quelle = os.path.abspath(__file__)
    s = io.open(quelle, encoding="utf-8").read()
    neu = 'OEFFENTLICH = {"n": %d, "e": %d}' % (n, e)
    s2 = re.sub(r'^OEFFENTLICH = \{.*\}$', neu, s, count=1, flags=re.M)
    if s2 == s:
        raise SystemExit("Konnte den oeffentlichen Schluessel nicht eintragen.")
    io.open(quelle, "w", encoding="utf-8", newline="").write(s2)
    return n, e


def geheim_lesen():
    try:
        return json.load(io.open(GEHEIM, encoding="utf-8"))
    except (OSError, ValueError):
        raise SystemExit("Kein privater Schluessel. Einmalig anlegen:\n"
                         "    python Werkzeuge/lizenz.py schluessel")


# --------------------------------------------------------------- Ausstellen
def _plus_monate(monate):
    j, m, t = [int(x) for x in _heute().split("-")]
    m += monate
    j += (m - 1) // 12
    m = (m - 1) % 12 + 1
    t = min(t, [31, 29 if (j % 4 == 0 and j % 100) or j % 400 == 0 else 28,
                31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1])
    return "%04d-%02d-%02d" % (j, m, t)


def ausstellen(anfrage, name, mail, monate=12):
    """Aus der Anforderung des Kunden einen unterschriebenen Schein machen."""
    a = anforderung_lesen(anfrage)
    lesbar = len([x for x in a["h"] if x])
    d = {"name": name, "mail": mail, "code": a["c"], "rechner": a["h"],
         "noetig": min(NOETIG, lesbar),
         "ab": _heute(), "bis": _plus_monate(monate), "art": "jahr"}
    d["sig"] = unterschreiben(d, geheim_lesen())
    return d




# --------------------------------------------------------------- Gutscheine
# Ein Schein wird fuer einen bestimmten Rechner ausgestellt; dafuer muss der
# Kunde erst seine TWQ-Zeile schicken. Ein Gutschein geht den anderen Weg: Er
# wird im Voraus ausgestellt, ohne den Rechner zu kennen, und die Kundin fuegt
# ihn einfach ein.
#
# Die Laufzeit steht IM Gutschein und ist mitunterschrieben — sie laesst sich
# also nicht verlaengern, auch nicht durch Bearbeiten der Datei. Unterschrieben
# wird hier, beim Ausstellen; auf dem Rechner der Kundin liegt kein privater
# Schluessel, dort kann nichts unterschrieben werden. Deshalb traegt der
# Gutschein ein festes Enddatum und keine "Monate ab Einloesen".
#
# Was er NICHT kann, damit es niemand anders verspricht: Wer ihn hat, kann ihn
# einloesen — auch ein zweites Mal auf einem anderen Rechner. Offline gibt es
# keine Stelle, die sich "schon benutzt" merken koennte. Der Rechner, auf dem
# er zuerst eingeloest wurde, wird zwar vermerkt und beim Start angezeigt, aber
# dieser Vermerk ist ein Hinweis, kein Riegel.

def gutschein_ausstellen(name, mail, monate=4):
    d = {"typ": "gutschein", "name": name, "mail": mail,
         "ab": _heute(), "bis": _plus_monate(int(monate)),
         "nr": base64.b32encode(os.urandom(5)).decode("ascii").rstrip("=")}
    d["sig"] = unterschreiben(d, geheim_lesen())
    roh = json.dumps(d, ensure_ascii=False, sort_keys=True,
                     separators=(",", ":")).encode("utf-8")
    return "TWG" + base64.urlsafe_b64encode(roh).decode("ascii").rstrip("=")


def gutschein_lesen(text):
    t = re.sub(r"\s+", "", text or "")
    if not t.startswith("TWG"):
        raise ValueError("Das ist kein Gutschein — er beginnt mit TWG.")
    t = t[3:]
    try:
        d = json.loads(base64.urlsafe_b64decode(t + "=" * (-len(t) % 4)))
    except Exception:
        raise ValueError("Der Gutschein ist unvollständig oder verstümmelt.")
    if not isinstance(d, dict) or d.get("typ") != "gutschein":
        raise ValueError("Das ist kein Gutschein.")
    if not unterschrift_gueltig(d):
        raise ValueError("Die Unterschrift stimmt nicht — bitte beim Absender nachfragen.")
    if _tage_zwischen(_heute(), d.get("bis") or "1970-01-01") < 0:
        raise ValueError("Dieser Gutschein ist am %s abgelaufen." % d.get("bis"))
    return d


def gutschein_einloesen(text):
    """Legt den Gutschein als lizenz.dat ab und vermerkt diesen Rechner."""
    g = gutschein_lesen(text)
    d = {"art": "gutschein",
         "gutschein": re.sub(r"\s+", "", text or ""),
         "name": g.get("name", ""), "mail": g.get("mail", ""),
         "bis": g.get("bis", ""), "nr": g.get("nr", ""),
         "rechner": abdruck(), "eingeloest": _heute()}
    io.open(SCHEIN, "w", encoding="utf-8", newline="").write(
        json.dumps(d, ensure_ascii=False, indent=1))
    return d


def gutschein_stand(d):
    """Der Zustand eines eingeloesten Gutscheins. Geprueft wird die
       Unterschrift des Gutscheins selbst — alles andere in der Datei ist
       Beiwerk und koennte verändert sein, ohne dass es etwas nuetzt."""
    try:
        g = gutschein_lesen(d.get("gutschein") or "")
    except ValueError:
        return None
    jetzt = abdruck()
    treffer = passt(d.get("rechner") or [], jetzt)
    rest = _tage_zwischen(_heute(), g.get("bis") or "1970-01-01")
    return {"darf": rest >= 0, "art": "gutschein" if rest >= 0 else "abgelaufen",
            "rest": max(0, rest), "name": g.get("name", ""), "bis": g.get("bis", ""),
            "code": code(jetzt), "treffer": treffer,
            "fremd": treffer < min(NOETIG, len([x for x in (d.get("rechner") or []) if x]))}


# --------------------------------------------------------------------- CLI
def main(argv):
    was = (argv[1] if len(argv) > 1 else "stand").lower()

    if was == "stand":
        s = stand()
        print("Rechnercode:   %s" % s["code"])
        roh = abdruck()
        print("Kennungen:     %d von %d lesbar"
              % (len([x for x in roh if x]), len(roh)))
        print("Zustand:       %s" % s["art"])
        if s["art"] == "schein":
            print("Ausgestellt:   %s, gueltig bis %s (%d Tage)"
                  % (s["name"], s["bis"], s["rest"]))
        elif s["art"] == "schonfrist":
            print("Schonfrist:    noch %d von %d Tagen" % (s["rest"], SCHONFRIST))
        print("Darf laufen:   %s" % ("ja" if s["darf"] else "NEIN"))
        return 0

    if was == "code":
        print(code())
        return 0

    if was == "anforderung":
        print(anforderung())
        return 0

    if was == "schluessel":
        n, e = schluessel_erzeugen()
        print("Schluesselpaar angelegt.")
        print("  privat:      %s   <- niemals ausliefern, niemals in Git" % GEHEIM)
        print("  oeffentlich: in lizenz.py eingetragen (%d Bit)" % n.bit_length())
        return 0

    if was == "gutschein":
        if len(argv) < 4:
            print('Aufruf: lizenz.py gutschein "Name" mail@x.de [Monate]')
            return 2
        monate = int(argv[4]) if len(argv) > 4 else 4
        g = gutschein_ausstellen(argv[2], argv[3], monate)
        ordner = os.path.join(HEIM, "Gutscheine")
        os.makedirs(ordner, exist_ok=True)
        gl = gutschein_lesen(g)
        ziel = os.path.join(ordner, "gutschein-%s.txt" % gl["nr"])
        io.open(ziel, "w", encoding="utf-8", newline="").write(g + "\n")
        print("Gutschein fuer %s, gueltig bis %s (%d Monate)"
              % (argv[2], gl["bis"], monate))
        print(ziel)
        print()
        print(g)
        print()
        print("Diese Zeile weitergeben. Die Kundin fuegt sie in der App unter")
        print("'Gutschein einloesen' ein — mehr ist nicht noetig.")
        return 0

    if was == "einloesen":
        if len(argv) < 3:
            print("Aufruf: lizenz.py einloesen TWG...")
            return 2
        d = gutschein_einloesen(argv[2])
        print("Eingeloest fuer %s, gueltig bis %s" % (d["name"], d["bis"]))
        return 0

    if was == "ausstellen":
        if len(argv) < 5:
            print('Aufruf: lizenz.py ausstellen TWQ... "Name" mail@x.de [Monate]')
            return 2
        monate = int(argv[5]) if len(argv) > 5 else 12
        d = ausstellen(argv[2], argv[3], argv[4], monate)
        # Je Kunde ein eigener Ordner, die Datei darin heisst schon richtig.
        # Haette sie den Code im Namen, muesste der Kunde sie umbenennen — und
        # ein Teil von ihnen wuerde es nicht tun und stattdessen schreiben,
        # dass es nicht geht.
        ordner = os.path.join(HEIM, "Lizenzen", d["code"].replace("-", ""))
        os.makedirs(ordner, exist_ok=True)
        ziel = os.path.join(ordner, "lizenz.dat")
        io.open(ziel, "w", encoding="utf-8", newline="").write(
            json.dumps(d, ensure_ascii=False, indent=1))
        print("Schein fuer %s, gueltig bis %s" % (d["name"], d["bis"]))
        print(ziel)
        print("\nDem Kunden schicken; er legt sie als lizenz.dat neben")
        print("'Takewrite starten.bat'.")
        return 0

    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
