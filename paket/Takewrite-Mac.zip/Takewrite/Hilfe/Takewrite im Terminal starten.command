#!/bin/bash
# ---------------------------------------------------------------------------
#  Nur für den Fall, dass etwas klemmt.
#
#  Takewrite startet normalerweise still — ohne Fenster, ohne Ausgabe. Das ist
#  im Alltag richtig, aber unbrauchbar, wenn man wissen will, WARUM etwas
#  nicht geht. Diese Datei startet dasselbe Programm mit offener Ausgabe:
#  Alles, was Takewrite zu sagen hat, steht danach im Terminalfenster und
#  lässt sich kopieren und schicken.
#
#  Im Alltag braucht man sie nicht. Einfach liegen lassen.
# ---------------------------------------------------------------------------
set -u
cd "$(dirname "$0")/.." || exit 1
heim="$(pwd)"

echo "Takewrite — Start mit Ausgabe"
echo "Ordner: $heim"
echo

py=""
for kandidat in "${TAKEWRITE_PYTHON:-}" /opt/homebrew/bin/python3 \
                /usr/local/bin/python3 "$HOME/.pyenv/shims/python3" \
                /usr/bin/python3; do
  if [ -n "$kandidat" ] && [ -x "$kandidat" ] \
     && "$kandidat" -c "import sys" >/dev/null 2>&1; then
    py="$kandidat"
    break
  fi
done

if [ -z "$py" ]; then
  echo "Kein python3 gefunden."
  echo
  echo "macOS bringt Python nicht von Haus aus mit. Apple liefert es als Teil"
  echo "der Command Line Tools mit — dieser Befehl holt sie:"
  echo
  echo "    xcode-select --install"
  echo
  echo "Danach Takewrite normal starten."
  echo
  read -r -p "Zum Schließen die Eingabetaste drücken. "
  exit 1
fi

echo "Python:  $py"
"$py" -c "import sys; print('Fassung:', sys.version.split()[0])"
echo
echo "--- Prüfung -----------------------------------------------------------"
"$py" "$heim/Werkzeuge/starter.py" --probe
echo
echo "--- Start -------------------------------------------------------------"
"$py" "$heim/Werkzeuge/starter.py" --still
echo
echo "Fertig. Wenn oben ein Fehler steht, schick ihn an support@takewrite.de."
echo
read -r -p "Zum Schließen die Eingabetaste drücken. "
