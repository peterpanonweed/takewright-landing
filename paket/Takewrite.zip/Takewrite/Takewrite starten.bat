@echo off
rem ---------------------------------------------------------------
rem  TAKEWRITE - Synchronbuecher am Bild schreiben
rem
rem  Startet ohne Fenster. Die Arbeit macht
rem  Werkzeuge\starter.py --still : legt beim ersten Mal die
rem  Verknuepfungen an, faehrt den Dienst im Hintergrund hoch und
rem  oeffnet den Browser auf dem Ladebild.
rem
rem  Beendet wird in der App ueber "Beenden" - nicht mehr durch das
rem  Schliessen eines Fensters, denn es gibt keins mehr. Bleibt die
rem  Seite weg, schaltet sich der Dienst nach 20 Minuten selbst ab.
rem
rem  Wer das Konsolenmenue braucht (Projekt waehlen, anlegen,
rem  stilllegen), ruft starter.py ohne --still auf.
rem ---------------------------------------------------------------
setlocal

rem  Die mitgelieferte Laufzeit hat Vorrang, dann die des Entwicklers,
rem  zuletzt ein Python aus dem Systempfad. pythonw startet ohne Fenster.
set "PYW=%~dp0Laufzeit\pythonw.exe"
if not exist "%PYW%" set "PYW=G:\Python314\pythonw.exe"
if not exist "%PYW%" set "PYW=pythonw"

start "" "%PYW%" "%~dp0Werkzeuge\starter.py" --still
exit
