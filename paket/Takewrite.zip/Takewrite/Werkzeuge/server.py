# -*- coding: utf-8 -*-
"""Der Takewrite-Server — liefert die App aus und sichert den Arbeitsstand.

Der eingebaute Webserver von Python kann nur ausliefern. Dieser hier nimmt
zusaetzlich den Arbeitsstand entgegen und legt ihn als Datei in den
Projektordner. Das ist der Unterschied zwischen "der Stand liegt im Browser"
und "der Stand liegt auf der Festplatte":

    takewrite-stand.json                  der aktuelle Stand
    Sicherungen/stand-JJJJ-MM-TT.json     ein Stand je Arbeitstag

Kein Dialog, keine Berechtigung, kein Vergessen. Wird der Browserspeicher
geleert, holt sich die App den Stand beim naechsten Oeffnen aus der Datei.

    python Werkzeuge/server.py <Port> <Ordner>
"""
import io, json, os, re, shutil, sys, threading, time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer


class Ausschnitt:
    """Gibt hoechstens so viele Bytes heraus, wie der angeforderte Bereich
       umfasst. Ohne diese Fessel schoebe copyfile() den ganzen Rest der Datei
       hinterher — bei acht Gigabyte Film das Ende jeder Sprungmarke."""

    def __init__(self, datei, rest):
        self.datei, self.rest = datei, rest

    def read(self, wieviel=-1):
        if self.rest <= 0:
            return b""
        if wieviel is None or wieviel < 0 or wieviel > self.rest:
            wieviel = self.rest
        roh = self.datei.read(wieviel)
        self.rest -= len(roh)
        return roh

    def close(self):
        self.datei.close()

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace", line_buffering=True)

STAND_DATEI = "takewrite-stand.json"
SICHERUNGEN = "Sicherungen"
KACHEL      = "kachel.jpg"
# Was dem Nutzer gehoert und nicht dem Film: Tastenbelegung, Spaltenbreite,
# Schriftgroesse, weggeklickte Hinweise. Das lag bisher im localStorage — und
# der ist nach Adresse SAMT PORT getrennt. Weil jedes Projekt einen eigenen
# Port hat, begann jedes Projekt mit Werkseinstellungen. Hier liegt es einmal
# fuer die ganze Installation.
EINSTELLUNGEN = "einstellungen.json"
TAGESABSTAND = 600          # hoechstens alle zehn Minuten eine Tageskopie

# Projektliste lesen, schreiben, starten — das steht alles schon im Starter.
# Hier wird es benutzt, nicht abgeschrieben: zwei Fassungen derselben Regeln
# ueber dieselbe Datei waeren zwei Wahrheiten, und eine davon veraltet.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import starter                                              # noqa: E402


def sicherer_name(name):
    """Aus einem Projektnamen einen Ordnernamen machen, den Windows nimmt."""
    sauber = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", name).strip(" .")
    return sauber[:60] or "Projekt"


def zeilenzahl(was):
    """Wie viele nicht geloeschte Zeilen ein Stand hat — als Bytefolge oder
       als Dateipfad. Unlesbares zaehlt als 0; die Entscheidung darueber
       trifft der Aufrufer."""
    try:
        if isinstance(was, (bytes, bytearray)):
            d = json.loads(bytes(was).decode("utf-8"))
        else:
            with io.open(was, encoding="utf-8") as f:
                d = json.load(f)
        return sum(1 for z in (d.get("zeilen") or []) if not z.get("d"))
    except Exception:
        return 0


class Takewrite(SimpleHTTPRequestHandler):
    ordner = "."

    def __init__(self, *a, **k):
        super().__init__(*a, directory=Takewrite.ordner, **k)

    # --- Was der Browser schickt ---
    def do_POST(self):
        weg = self.path.split("?")[0].rstrip("/")
        if weg == "/kachel":
            self.kachel_nehmen()
            return
        if weg == "/projekt":
            self.projekt_anlegen()
            return
        if weg == "/einstellungen":
            self.einstellungen_merken()
            return
        if weg == "/projekt/stilllegen":
            self.projekt_stilllegen()
            return
        if weg == "/projekt/starten":
            self.projekt_starten()
            return
        if weg == "/film/merken":
            self.film_merken()
            return
        if weg not in ("/stand", "/punkt"):
            self.send_error(404, "Nur /stand, /punkt, /kachel und /projekt "
                                 "nehmen etwas entgegen")
            return
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
            if laenge <= 0 or laenge > 64 * 1024 * 1024:
                raise ValueError("unglaubwuerdige Laenge")
            roh = self.rfile.read(laenge)
            d = json.loads(roh.decode("utf-8"))       # muss lesbar sein
            if not isinstance(d, dict) or "zeilen" not in d:
                raise ValueError("kein Arbeitsstand")
        except Exception as e:
            self.send_error(400, "Nicht angenommen: %s" % e)
            return

        try:
            name = self.punkt_setzen(roh) if weg == "/punkt" else self.schreiben(roh)
        except Exception as e:
            self.send_error(500, "Konnte nicht schreiben: %s" % e)
            return

        # "abgewiesen" ist kein Erfolg. Meldete der Server hier ok, zeigte die
        # Seite "gesichert" an, waehrend auf der Platte etwas anderes steht —
        # die gefaehrlichste aller Rueckmeldungen.
        angenommen = (name != "abgewiesen")
        antwort = json.dumps({"ok": angenommen,
                              "zeilen": len(d.get("zeilen") or []),
                              "grund": None if angenommen else "leerer Stand abgewiesen",
                              "name": name}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(antwort)))
        self.end_headers()
        self.wfile.write(antwort)

    # --- Die Kachel: ein Standbild als Gesicht des Projekts ---
    def kachel_nehmen(self):
        """Ein Bild aus dem laufenden Film, vom Browser als JPEG geschickt.
           Es landet im Projektordner, nicht im Browserspeicher — damit
           gehoert die Kachel zum Film und ueberlebt jedes geleerte Profil."""
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
            if laenge <= 0 or laenge > 8 * 1024 * 1024:
                raise ValueError("unglaubwuerdige Laenge")
            roh = self.rfile.read(laenge)
            if not roh.startswith(b"\xff\xd8\xff"):
                raise ValueError("kein JPEG")
        except Exception as e:
            self.send_error(400, "Nicht angenommen: %s" % e)
            return
        ziel = os.path.join(Takewrite.ordner, KACHEL)
        vorlaeufig = ziel + ".neu"
        try:
            with open(vorlaeufig, "wb") as f:
                f.write(roh); f.flush(); os.fsync(f.fileno())
            os.replace(vorlaeufig, ziel)
        except Exception as e:
            self.send_error(500, "Konnte nicht schreiben: %s" % e)
            return
        print("%s  Kachel aufgenommen (%d KB)"
              % (time.strftime("%H:%M:%S"), len(roh) // 1024))
        self.json_schicken({"ok": True, "groesse": len(roh)})

    def einstellungen_merken(self):
        """Nimmt einzelne Werte entgegen und legt sie zu den vorhandenen.
           Absichtlich zusammenfuehren statt ersetzen: Zwei offene Projekte
           schreiben sonst abwechselnd ihren Stand ueber den des anderen."""
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
            if laenge <= 0 or laenge > 256 * 1024:
                raise ValueError("unglaubwuerdige Laenge")
            neu = json.loads(self.rfile.read(laenge).decode("utf-8"))
            if not isinstance(neu, dict):
                raise ValueError("kein Satz von Einstellungen")
        except Exception as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 400)
            return

        alles = self.einstellungen_lesen()
        alles.update(neu)
        ziel = self.einstellungen_pfad()
        vorlaeufig = ziel + ".neu"
        try:
            with io.open(vorlaeufig, "w", encoding="utf-8", newline="\n") as f:
                json.dump(alles, f, ensure_ascii=False, indent=1, sort_keys=True)
                f.flush()
                os.fsync(f.fileno())
            os.replace(vorlaeufig, ziel)
        except OSError as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 500)
            return
        self.json_schicken({"ok": True, "anzahl": len(alles)})

    def ordner_zeigen(self):
        """Blaettert durch die Ordner der Platte — fuer den Waehler in der App.

        Der Umweg ueber den Windows-Ordnerdialog war eine Sackgasse: Ein
        Vorgang ohne Vordergrundrecht — und der Server steckt in einem
        minimierten Konsolenfenster — bekommt vom System kein Fenster. Am
        29.08.2026 lief der Dialog unsichtbar hinter allem, und in der App
        blieb ein Knopf haengen, der nie zurueckkam. Gemessen: kein neues
        Fenster, kein Vordergrundwechsel.

        Also blaettert die App selbst. Der Server sagt nur, was da ist."""
        p = self.frage("p", "")
        if not p:
            # Ohne Vorgabe: die Laufwerke, und daneben die Orte, an denen
            # schon Projekte liegen — dort sucht man fast immer.
            eintraege, gesehen = [], set()
            for name, pfad in starter.liste_lesen():
                eltern = os.path.dirname(os.path.abspath(pfad.rstrip("\\/")))
                if os.path.isdir(eltern) and eltern.lower() not in gesehen:
                    gesehen.add(eltern.lower())
                    eintraege.append({"name": eltern, "pfad": eltern, "film": False})
            for buchstabe in "CDEFGHIJKLMNOPQRSTUVWXYZ":
                w = buchstabe + ":\\"
                if os.path.isdir(w) and w.lower() not in gesehen:
                    gesehen.add(w.lower())
                    eintraege.append({"name": w, "pfad": w, "film": False})
            self.json_schicken({"aktuell": "", "hoch": None, "ordner": eintraege})
            return

        p = os.path.abspath(p)
        if not os.path.isdir(p):
            self.json_schicken({"ok": False, "grund": "Kein Ordner: %s" % p}, 400)
            return
        eintraege = []
        try:
            for name in sorted(os.listdir(p), key=str.lower):
                voll = os.path.join(p, name)
                if not os.path.isdir(voll) or name.startswith("."):
                    continue
                try:
                    film = any(k.lower().endswith(self.FILMENDUNGEN)
                               for k in os.listdir(voll))
                except OSError:
                    film = False
                eintraege.append({"name": name, "pfad": voll, "film": film})
        except OSError as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 400)
            return
        hoch = os.path.dirname(p.rstrip("\\/"))
        if hoch == p or not os.path.isdir(hoch):
            hoch = ""
        eigener = any(k.lower().endswith(self.FILMENDUNGEN) for k in os.listdir(p))
        self.json_schicken({"aktuell": p, "hoch": hoch,
                            "hatFilm": eigener, "ordner": eintraege})

    def projekt_starten(self):
        """Ein Projekt hochfahren, das gerade nicht laeuft.

           Jedes Projekt hat einen eigenen Server. War er zu, fuehrte ein Klick
           auf seine Kachel ins Leere: Der Browser ging auf eine Adresse, auf
           der niemand horcht, zeigte eine Fehlerseite — und die App war weg.
           Am 29.08.2026 sah das aus wie ein Absturz. Eine Kachel, die man
           anklicken kann, muss auch irgendwohin fuehren."""
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
            nr = int(json.loads(self.rfile.read(laenge).decode("utf-8")).get("nr"))
        except Exception as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 400)
            return

        projekte = starter.liste_lesen()
        if not (0 <= nr < len(projekte)):
            self.json_schicken({"ok": False, "grund": "Kein solches Projekt"}, 400)
            return
        name, pfad = projekte[nr]
        port = starter.PORT0 + nr
        if starter.ist_stillgelegt(name):
            self.json_schicken({"ok": False, "grund": "Projekt ist stillgelegt"}, 400)
            return
        if starter.lauscht(port):
            self.json_schicken({"ok": True, "schon": True, "port": port})
            return
        if not os.path.isdir(pfad):
            self.json_schicken({"ok": False,
                                "grund": "Den Ordner gibt es nicht: %s" % pfad}, 400)
            return
        try:
            starter.starten(name, pfad, port, oeffnen=False)
        except Exception as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 500)
            return
        # Warten, bis er wirklich horcht — sonst schickt die App den Browser
        # los, bevor jemand da ist, und der Fehler waere derselbe wie vorher.
        for _ in range(60):
            if starter.lauscht(port):
                print("%s  Projekt gestartet: %s  Port %d"
                      % (time.strftime("%H:%M:%S"), name, port))
                self.json_schicken({"ok": True, "port": port})
                return
            time.sleep(0.25)
        self.json_schicken({"ok": False, "grund": "Der Server kam nicht hoch"}, 500)

    def projekt_stilllegen(self):
        """Nimmt ein Projekt aus der Liste — und ruehrt nichts auf der Platte
           an. Weder der Filmordner noch das Buch werden angefasst; es
           verschwindet nur die Kachel. Zurueckholen geht, indem man die Tilde
           vor dem Namen in Projekte.txt loescht.

           Die Zeile bleibt als Platzhalter stehen. Naehme man sie heraus,
           ruecken alle folgenden Projekte einen Port vor, und ihr im Browser
           liegender Arbeitsstand gehoerte ploetzlich zu einem anderen Film."""
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
            d = json.loads(self.rfile.read(laenge).decode("utf-8"))
            nr = int(d.get("nr"))
        except Exception as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 400)
            return

        projekte = starter.liste_lesen()
        if not (0 <= nr < len(projekte)):
            self.json_schicken({"ok": False, "grund": "Kein solches Projekt"}, 400)
            return
        name, pfad = projekte[nr]
        if starter.ist_stillgelegt(name):
            self.json_schicken({"ok": True, "schon": True, "name": name})
            return
        if os.path.normcase(os.path.abspath(pfad)) == \
           os.path.normcase(os.path.abspath(Takewrite.ordner)):
            self.json_schicken({"ok": False,
                                "grund": "Das laufende Projekt kann sich nicht "
                                         "selbst stilllegen"}, 400)
            return

        projekte[nr] = (starter.STILLGELEGT + " " + name, pfad)
        try:
            starter.liste_schreiben(projekte)
        except OSError as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 500)
            return
        print("%s  Projekt stillgelegt: %s  (Ordner unberuehrt)"
              % (time.strftime("%H:%M:%S"), name))
        self.json_schicken({"ok": True, "name": name})

    # --- Ein neues Projekt, aus der App heraus ---
    def projekt_anlegen(self):
        """Der Ordnerpfad kommt getippt oder eingefuegt. Ein Dateidialog im
           Browser gibt keinen Pfad heraus — er darf es nicht, und das ist
           richtig so. Darum das Feld zum Einfuegen."""
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
            d = json.loads(self.rfile.read(laenge).decode("utf-8"))
            name = (d.get("name") or "").strip()
            pfad = (d.get("ordner") or "").strip().strip('"')
            if not name:
                raise ValueError("Ein Name wird gebraucht")
            if "|" in name or "\n" in name:
                raise ValueError("Der Name darf kein | enthalten")
            if not pfad:
                # Kein Ordner genannt — dann legt Takewrite einen an.
                # Ein Projekt braucht einen Ort, an dem sein Buch liegt; dass
                # der Nutzer ihn heraussucht, ist eine Zumutung ohne Gegenwert.
                # Der Film kommt ueber den Player, das Rohbuch ueber den
                # Import: Beide muessen nirgendwo bestimmtes liegen.
                pfad = os.path.join(starter.HEIM, "Projekte", sicherer_name(name))
                os.makedirs(pfad, exist_ok=True)
            elif not os.path.isdir(pfad):
                raise ValueError("Diesen Ordner gibt es nicht: %s" % pfad)
        except Exception as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 400)
            return

        # Schon in der Liste? Dann nicht doppelt anlegen — die Reihenfolge
        # bestimmt den Port und damit, wo der Arbeitsstand liegt. Ein zweiter
        # Eintrag auf denselben Ordner waere ein zweiter, leerer Arbeitsstand.
        projekte = starter.liste_lesen()
        neu = os.path.normcase(os.path.abspath(pfad))
        for i, (n, p) in enumerate(projekte):
            if os.path.normcase(os.path.abspath(p)) != neu:
                continue
            if not starter.ist_stillgelegt(n):
                self.json_schicken({"ok": True, "schon": True, "nr": i,
                                    "name": n, "port": starter.PORT0 + i})
                return
            # Der Ordner gehoert zu einem stillgelegten Projekt. Wer ihn
            # wieder anlegt, will es zurueck — und bekam bis zum 29.08.2026
            # stattdessen "steht schon in der Liste" und kam nie wieder an
            # sein Projekt. Der Platz bleibt derselbe, also auch der Port und
            # damit der Arbeitsstand: Es ist dasselbe Projekt, nicht ein neues.
            port = starter.PORT0 + i
            projekte[i] = (name, pfad)
            try:
                starter.liste_schreiben(projekte)
                starter.starten(name, pfad, port, oeffnen=False)
            except Exception as e:
                self.json_schicken({"ok": False, "grund": str(e)}, 500)
                return
            for _ in range(60):
                if starter.lauscht(port):
                    break
                time.sleep(0.25)
            print("%s  Projekt zurueckgeholt: %s  Port %d"
                  % (time.strftime("%H:%M:%S"), name, port))
            self.json_schicken({"ok": True, "zurueck": True, "nr": i,
                                "name": name, "port": port})
            return

        projekte.append((name, pfad))
        nr = len(projekte) - 1
        port = starter.PORT0 + nr
        try:
            starter.liste_schreiben(projekte)
            if not starter.starten(name, pfad, port, oeffnen=False):
                raise RuntimeError("Der Server kam nicht hoch")
        except Exception as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 500)
            return
        # Warten, bis er horcht: Die App wechselt gleich hinueber, und sie darf
        # nicht auf eine Adresse gehen, an der noch niemand da ist.
        for _ in range(60):
            if starter.lauscht(port):
                break
            time.sleep(0.25)
        print("%s  Projekt angelegt: %s  Port %d"
              % (time.strftime("%H:%M:%S"), name, port))
        self.json_schicken({"ok": True, "nr": nr, "name": name, "port": port})

    def schreiben(self, roh):
        ziel = os.path.join(Takewrite.ordner, STAND_DATEI)

        # Ein leeres Buch loescht nie ein volles.
        #
        # Am 02.09.2026 waren nach einem Strg+F5 1160 geschriebene Zeilen weg.
        # Der Film liegt im Projektordner und laedt beim Start von selbst; das
        # Vorbelegen des Titels aus dem Dateinamen loest ein Sichern aus, und
        # das lief los, bevor das Holen der 174-KB-Standdatei zurueck war. Der
        # harte Neuladen umgeht den Zwischenspeicher und macht genau dieses
        # Rennen wahrscheinlich.
        #
        # Die Ursache ist in der Seite behoben. Dieser Riegel steht trotzdem —
        # er haelt unabhaengig davon, WARUM ein leerer Stand ankommt, und er
        # ist die letzte Stelle, an der es noch jemand merken kann. Eine
        # Ablage, die sich auf Zuruf selbst leeren laesst, ist keine.
        neu_n = zeilenzahl(roh)
        alt_n = zeilenzahl(ziel) if os.path.exists(ziel) else 0
        if neu_n == 0 and alt_n >= 10:
            print("%s  ABGEWIESEN: leerer Stand haette %d Zeilen ueberschrieben"
                  % (time.strftime("%H:%M:%S"), alt_n))
            return "abgewiesen"

        # Erst danebenschreiben, dann umbenennen: ein Absturz mittendrin
        # darf niemals eine halbe Datei hinterlassen.
        vorlaeufig = ziel + ".neu"
        with open(vorlaeufig, "wb") as f:
            f.write(roh)
            f.flush()
            os.fsync(f.fileno())
        os.replace(vorlaeufig, ziel)

        # Tageskopie — damit man auch auf gestern zurueck kann
        tag = time.strftime("%Y-%m-%d")
        ordner = os.path.join(Takewrite.ordner, SICHERUNGEN)
        os.makedirs(ordner, exist_ok=True)
        kopie = os.path.join(ordner, "stand-%s.json" % tag)
        if not os.path.exists(kopie):
            shutil.copy2(ziel, kopie)
        elif time.time() - os.path.getmtime(kopie) > TAGESABSTAND:
            # Eine Tageskopie wird NIE durch einen viel duenneren Stand
            # ersetzt. Am 29.08.2026 wurde ein Projekt auf einem neuen Port
            # geoeffnet; der Browserspeicher war dort leer, die App sicherte
            # den leeren Stand — und aus 173 KB Tageskopie wurden 200 Byte
            # mit "zeilen":[]. Gerettet hat den Tag nur ein Sicherungspunkt
            # von Hand. Ein Sicherungsnetz, das sich selbst leeren kann, ist
            # keines.
            neu, alt = zeilenzahl(roh), zeilenzahl(kopie)
            if alt >= 10 and neu * 2 < alt:
                print("%s  Tageskopie behalten: neuer Stand hat %d statt %d "
                      "Zeilen" % (time.strftime("%H:%M:%S"), neu, alt))
            else:
                shutil.copy2(ziel, kopie)
        return STAND_DATEI

    def punkt_setzen(self, roh):
        """Ein Sicherungspunkt von Hand — traegt Datum und Uhrzeit und wird
           nie ueberschrieben. Das ist der Stand, auf den man zurueck kann."""
        # Ein leerer Punkt ist nicht nur nutzlos, er ist gefaehrlich: Er steht
        # oben in der Liste und sieht aus wie der juengste Stand. Am 02.09.2026
        # lag genau so einer mit 215 Byte im Ordner.
        ziel_stand = os.path.join(Takewrite.ordner, STAND_DATEI)
        if zeilenzahl(roh) == 0 and os.path.exists(ziel_stand)            and zeilenzahl(ziel_stand) >= 10:
            print("%s  ABGEWIESEN: leerer Sicherungspunkt" % time.strftime("%H:%M:%S"))
            return "abgewiesen"

        ordner = os.path.join(Takewrite.ordner, SICHERUNGEN)
        os.makedirs(ordner, exist_ok=True)
        name = "punkt-%s.json" % time.strftime("%Y-%m-%d-%H%M%S")
        ziel = os.path.join(ordner, name)
        with open(ziel, "wb") as f:
            f.write(roh); f.flush(); os.fsync(f.fileno())
        self.schreiben(roh)                      # der laufende Stand zieht mit
        print("%s  Sicherungspunkt: %s" % (time.strftime("%H:%M:%S"), name))
        return name

    # --- Die vorhandenen Sicherungen aufzaehlen ---
    def do_GET(self):
        weg = self.path.split("?")[0].rstrip("/")
        if weg == "/sicherungen":
            self.liste_schicken()
            return
        if weg == "/projekte":
            self.projekte_schicken()
            return
        if weg == "/kachel":
            self.kachel_schicken()
            return
        if weg == "/filme":
            self.filme_schicken()
            return
        if weg == "/untertitel":
            self.untertitel_schicken()
            return
        if weg == "/einstellungen":
            self.einstellungen_schicken()
            return
        if weg == "/ordner":
            self.ordner_zeigen()
            return
        if weg == "/lizenz":
            self.lizenz_schicken()
            return
        super().do_GET()

    # --- Lizenzstand, damit die Seite ihn anzeigen kann ---
    def lizenz_schicken(self):
        """Nach draussen geht der Zustand, nie eine Seriennummer — nur ihr
           Hash, und den auch nur als kurzer Code zum Vorlesen."""
        try:
            import lizenz
            s = lizenz.stand()
            d = {"art": s["art"], "rest": s["rest"], "name": s["name"],
                 "bis": s["bis"], "code": s["code"], "darf": s["darf"],
                 "frist": lizenz.SCHONFRIST, "kontakt": lizenz.KONTAKT}
            if not s["darf"] or s["art"] == "schonfrist":
                d["anforderung"] = lizenz.anforderung()
        except Exception as e:
            d = {"art": "unbekannt", "fehler": str(e), "darf": True}
        self.json_schicken(d)

    # --- Einstellungen: gehoeren der Installation, nicht dem Projekt ---
    def einstellungen_pfad(self):
        return os.path.join(starter.HEIM, EINSTELLUNGEN)

    def einstellungen_lesen(self):
        try:
            with io.open(self.einstellungen_pfad(), encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def einstellungen_schicken(self):
        self.json_schicken(self.einstellungen_lesen())

    FILMENDUNGEN = (".mp4", ".m4v", ".mov", ".mkv", ".avi", ".mxf",
                    ".webm", ".mpg", ".mpeg", ".ts", ".wmv")

    UNTERTITELENDUNGEN = (".srt", ".vtt")

    def untertitel_schicken(self):
        """Untertiteldateien im Projektordner UND in Unterordnern.

           Bis zum 29.08.2026 sah die App nur direkt im Projektordner nach.
           Wer seine Transkripte ordentlich in einen Unterordner legt — und
           genau das tut man bei mehreren Fassungen —, bekam ein leeres Buch
           angeboten, obwohl die Datei danebenlag. Zwei Ebenen reichen fuer
           jede Ablage, die noch als Ordnung durchgeht."""
        aus = []

        def sammeln(ordner, davor, tiefe):
            try:
                namen = sorted(os.listdir(ordner), key=str.lower)
            except OSError:
                return
            for n in namen:
                voll = os.path.join(ordner, n)
                if os.path.isfile(voll) and n.lower().endswith(self.UNTERTITELENDUNGEN):
                    aus.append({"pfad": davor + n, "groesse": os.path.getsize(voll)})
                elif (tiefe > 0 and os.path.isdir(voll)
                      and not n.startswith(".") and n != SICHERUNGEN):
                    sammeln(voll, davor + n + "/", tiefe - 1)

        sammeln(Takewrite.ordner, "", 2)
        self.json_schicken({"untertitel": aus})

    # --- Den von Hand gewaehlten Film wiederfinden ---
    def projekt_json(self):
        return os.path.join(Takewrite.ordner, "projekt.json")

    def film_pfad(self):
        """Der gemerkte Film dieses Projekts, falls es ihn noch gibt."""
        try:
            with io.open(self.projekt_json(), encoding="utf-8") as f:
                p = (json.load(f) or {}).get("film") or ""
            return p if p and os.path.isfile(p) else ""
        except (OSError, ValueError):
            return ""

    def translate_path(self, path):
        """/film zeigt auf die gemerkte Datei, wo immer sie liegt. Ueber diesen
           Umweg gelten fuer sie dieselben Bereichsabrufe wie fuer alles
           andere — send_head() fragt ebenfalls hier.

           Und das Programm kommt aus der Installation, nicht aus dem
           Projektordner. Der Starter stempelt zwar beim Start eine Kopie
           dorthin, aber die altert: Wer ein Projekt vor einem Update angelegt
           hat, bekam ewig die alte App ausgeliefert — am 29.08.2026 liefen so
           drei verschiedene Fassungen nebeneinander, und ein Klick verhielt
           sich je nach Projekt anders. Eine Installation, ein Programm."""
        weg = path.split("?")[0].rstrip("/")
        if weg == "/film":
            p = self.film_pfad()
            if p:
                return p
        if weg == "/Takewright.html":
            p = os.path.join(starter.HEIM, "Takewright.html")
            if os.path.isfile(p):
                return p
        return super().translate_path(path)

    def film_merken(self):
        """Sucht eine von Hand gewaehlte Filmdatei auf der Platte und schreibt
           ihren Pfad in projekt.json.

           Ein Browser gibt beim Dateidialog keinen Pfad heraus — er darf es
           nicht. Damit wusste die App beim naechsten Oeffnen nicht mehr,
           welcher Film es war, und mit ihm fehlten Stelle und Zusammenhang.
           Name UND Groesse muessen stimmen; das ist eindeutig genug, und
           gesucht wird nur dort, wo schon Projekte liegen."""
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
            d = json.loads(self.rfile.read(laenge).decode("utf-8"))
            name = (d.get("name") or "").strip()
            groesse = int(d.get("groesse") or 0)
            if not name or groesse <= 0:
                raise ValueError("Name und Groesse werden gebraucht")
        except Exception as e:
            self.json_schicken({"ok": False, "grund": str(e)}, 400)
            return

        wurzeln, gesehen = [], set()
        for _, pfad in starter.liste_lesen():
            for kandidat in (pfad, os.path.dirname(os.path.abspath(pfad.rstrip("\\/")))):
                k = os.path.normcase(os.path.abspath(kandidat))
                if k not in gesehen and os.path.isdir(kandidat):
                    gesehen.add(k)
                    wurzeln.append(kandidat)

        for wurzel in wurzeln:
            for hier, ordner, dateien in os.walk(wurzel):
                # Nicht in die Tiefe wuchern — drei Ebenen reichen fuer jede
                # Ablage, die noch als Ordnung durchgeht.
                if hier[len(wurzel):].count(os.sep) >= 3:
                    ordner[:] = []
                    continue
                ordner[:] = [o for o in ordner
                             if not o.startswith(".") and o != SICHERUNGEN]
                if name in dateien:
                    voll = os.path.join(hier, name)
                    try:
                        if os.path.getsize(voll) == groesse:
                            self.film_eintragen(voll)
                            print("%s  Film gemerkt: %s"
                                  % (time.strftime("%H:%M:%S"), voll))
                            self.json_schicken({"ok": True, "pfad": voll})
                            return
                    except OSError:
                        pass
        self.json_schicken({"ok": False, "grund": "nicht gefunden"})

    def film_eintragen(self, voll):
        try:
            with io.open(self.projekt_json(), encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            d = {}
        d["film"] = voll
        with io.open(self.projekt_json(), "w", encoding="utf-8", newline="\n") as f:
            json.dump(d, f, ensure_ascii=False)

    def filme_schicken(self):
        """Was im Projektordner an Film liegt. Den Pfad kennt der Server ja —
           dann kann er auch nachsehen, statt den Nutzer bei jedem Start
           dieselbe Datei aus einem Dialog heraussuchen zu lassen."""
        aus = []
        try:
            namen = sorted(os.listdir(Takewrite.ordner), key=str.lower)
        except OSError:
            namen = []
        for n in namen:
            if not n.lower().endswith(self.FILMENDUNGEN):
                continue
            p = os.path.join(Takewrite.ordner, n)
            if os.path.isfile(p):
                aus.append({"name": n, "groesse": os.path.getsize(p)})
        # Der von Hand gewaehlte Film liegt meist woanders — er wird trotzdem
        # gemeldet, damit die App ihn beim naechsten Mal von selbst holt.
        gemerkt = self.film_pfad()
        self.json_schicken({
            "filme": aus,
            "gemerkt": ({"name": os.path.basename(gemerkt),
                         "groesse": os.path.getsize(gemerkt)} if gemerkt else None)})

    # --- Die Projekte, wie die App sie zeigt ---
    def frage(self, name, standard=""):
        from urllib.parse import parse_qs, urlparse
        w = parse_qs(urlparse(self.path).query).get(name)
        return w[0] if w else standard

    def projekte_schicken(self):
        """Alle Projekte aus Projekte.txt. Der Port ergibt sich aus der
           Reihenfolge — das ist dieselbe Rechnung wie im Starter, und darum
           steht sie dort, nicht hier."""
        hier = os.path.normcase(os.path.abspath(Takewrite.ordner))
        aus = []
        for i, (name, pfad) in enumerate(starter.liste_lesen()):
            if starter.ist_stillgelegt(name):
                continue            # Platz bleibt, Kachel nicht — siehe starter.py
            port = starter.PORT0 + i
            aus.append({
                "nr": i, "name": name, "ordner": pfad, "port": port,
                "laeuft": starter.lauscht(port),
                "kachel": os.path.exists(os.path.join(pfad, KACHEL)),
                "da": os.path.isdir(pfad),
                "dies": os.path.normcase(os.path.abspath(pfad)) == hier,
            })
        self.json_schicken({"projekte": aus})

    def kachel_schicken(self):
        """Die Kachel eines beliebigen Projekts. Noetig, weil jedes Projekt
           auf einem eigenen Port sitzt und der Browser aus Port 8794 nicht in
           den Ordner von 8795 sehen darf."""
        projekte = starter.liste_lesen()
        try:
            nr = int(self.frage("p", "-1"))
        except ValueError:
            nr = -1
        pfad = (projekte[nr][1] if 0 <= nr < len(projekte) else Takewrite.ordner)
        datei = os.path.join(pfad, KACHEL)
        if not os.path.exists(datei):
            self.send_error(404, "Keine Kachel")
            return
        with open(datei, "rb") as f:
            roh = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(roh)))
        self.end_headers()
        self.wfile.write(roh)

    def json_schicken(self, d, code=200):
        roh = json.dumps(d, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(roh)))
        self.end_headers()
        self.wfile.write(roh)

    def liste_schicken(self):
        ordner = os.path.join(Takewrite.ordner, SICHERUNGEN)
        aus = []
        if os.path.isdir(ordner):
            # Nach Zeit, nicht nach Namen. Alphabetisch stand "stand-..." ueber
            # "punkt-...", also erschien die Tageskopie oben, auch wenn ein
            # Sicherungspunkt sechs Minuten juenger war. Am 02.09.2026 hat
            # jemand deshalb den obersten Eintrag zurueckgeholt und damit die
            # aeltere, duennere Fassung erwischt. Eine Liste, die "neueste
            # zuerst" verspricht, muss nach der Zeit gehen.
            def wann(n):
                try: return os.path.getmtime(os.path.join(ordner, n))
                except OSError: return 0
            for name in sorted(os.listdir(ordner), key=wann, reverse=True):
                if not name.endswith(".json"):
                    continue
                p = os.path.join(ordner, name)
                eintrag = {"name": name, "groesse": os.path.getsize(p),
                           "zeit": int(os.path.getmtime(p) * 1000)}
                try:
                    d = json.load(io.open(p, encoding="utf-8"))
                    z = [x for x in (d.get("zeilen") or []) if not x.get("d")]
                    eintrag["rollen"] = len({(x.get("r") or "").strip()
                                             for x in z if (x.get("r") or "").strip()})
                    eintrag["mitRolle"] = sum(1 for x in z if (x.get("r") or "").strip())
                    eintrag["gesetzt"] = sum(1 for x in z if x.get("g"))
                    eintrag["titel"] = (d.get("kopf") or {}).get("Titel", "")
                    eintrag["stand"] = d.get("stand") or 0
                except Exception:
                    eintrag["fehler"] = True
                aus.append(eintrag)
        roh = json.dumps({"sicherungen": aus}, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(roh)))
        self.end_headers()
        self.wfile.write(roh)

    # --- Bereichsabrufe: die Bedingung dafuer, dass der Film von hier kommt ---
    def send_head(self):
        """Der eingebaute Handler kennt kein Range und schickt immer die ganze
           Datei. Fuer einen Film heisst das: Jeder Sprung beginnt den Download
           von vorn. Genau daran scheiterte es, den Film aus dem Projektordner
           zu laden, statt ihn von Hand auszuwaehlen."""
        bereich = (self.headers.get("Range") or "").strip()
        if not bereich:
            return super().send_head()
        treffer = re.match(r"^bytes=(\d*)-(\d*)$", bereich)
        if not treffer:
            return super().send_head()
        pfad = self.translate_path(self.path)
        if not os.path.isfile(pfad):
            return super().send_head()

        groesse = os.path.getsize(pfad)
        a, b = treffer.group(1), treffer.group(2)
        if a == "":                                   # bytes=-N : die letzten N
            if b == "":
                return super().send_head()
            von, bis = max(0, groesse - int(b)), groesse - 1
        else:
            von = int(a)
            bis = min(int(b), groesse - 1) if b else groesse - 1

        if groesse == 0 or von >= groesse or von > bis:
            self.send_response(416)
            self.send_header("Content-Range", "bytes */%d" % groesse)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return None

        datei = open(pfad, "rb")
        datei.seek(von)
        self.send_response(206)
        self.send_header("Content-Type", self.guess_type(pfad))
        self.send_header("Content-Range", "bytes %d-%d/%d" % (von, bis, groesse))
        self.send_header("Content-Length", str(bis - von + 1))
        self.send_header("Last-Modified",
                         self.date_time_string(int(os.path.getmtime(pfad))))
        self.end_headers()
        return Ausschnitt(datei, bis - von + 1)

    def end_headers(self):
        # Der Arbeitsstand darf nie aus dem Zwischenspeicher kommen
        self.send_header("Cache-Control", "no-store")
        # Sagt dem Browser, dass er springen darf, statt vorsichtshalber alles
        # am Stueck zu holen
        self.send_header("Accept-Ranges", "bytes")
        super().end_headers()

    def log_message(self, format, *args):
        # Nur Fehler und Sicherungen melden, nicht jede Bilddatei
        if args and str(args[0]).startswith(("POST", "GET /stand")):
            sys.stdout.write("%s  %s\n" % (time.strftime("%H:%M:%S"), args[0]))


def _stand(pfad):
    try:
        return os.path.getmtime(pfad)
    except OSError:
        return 0


def selbstueberwachung(server):
    """Wacht ueber die eigene Datei und startet den Vorgang neu, sobald eine
       neue Fassung ausgeliefert wurde.

       Die App wird bei jeder Anfrage frisch von der Platte gelesen, ist also
       sofort aktuell. Der Server dagegen ist ein Vorgang im Speicher: Nach
       einer Auslieferung bediente ein alter Server eine neue App und kannte
       deren neue Wege nicht. Wer mehrere Projekte offen hat, muesste jedes
       Fenster von Hand schliessen und neu oeffnen — und die Fenster stehen
       minimiert in der Taskleiste, man sieht sie nicht einmal.

       os.execv ersetzt den laufenden Vorgang durch sich selbst: dasselbe
       Fenster, derselbe Port, neuer Code. Der Lauschposten wird vorher
       geschlossen, damit der neue Vorgang den Port sofort bekommt."""
    hier = os.path.dirname(os.path.abspath(__file__))
    dateien = [os.path.abspath(__file__), os.path.join(hier, "starter.py")]
    vorher = {d: _stand(d) for d in dateien}
    while True:
        time.sleep(3)
        if all(vorher[d] == _stand(d) for d in dateien):
            continue
        # Kurz warten, damit eine noch laufende Kopie fertig geschrieben ist
        time.sleep(1.5)
        print("%s  Neue Fassung erkannt — der Server startet sich neu."
              % time.strftime("%H:%M:%S"))
        try:
            server.server_close()
        except Exception:
            pass
        try:
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception as e:                       # dann eben nicht
            print("Neustart nicht moeglich: %s" % e)
            return


def main():
    # Auch hier, nicht nur im Starter: Wer server.py von Hand aufruft, soll
    # nicht am Tor vorbeikommen. Ohne gueltigen Schein wird kein Port belegt —
    # es gibt dann keine Adresse, unter der die Seite zu haben waere.
    if not starter.lizenz_tor():
        return

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8794
    Takewrite.ordner = sys.argv[2] if len(sys.argv) > 2 else os.getcwd()
    print("Takewrite-Server")
    print("  Ordner: %s" % Takewrite.ordner)
    print("  Adresse: http://localhost:%d/Takewright.html" % port)
    print("  Arbeitsstand: %s  (+ Tageskopien in %s\\)" % (STAND_DATEI, SICHERUNGEN))
    print("  Dieses Fenster schliessen beendet das Projekt.")
    print()
    server = ThreadingHTTPServer(("127.0.0.1", port), Takewrite)
    threading.Thread(target=selbstueberwachung, args=(server,), daemon=True).start()
    server.serve_forever()


if __name__ == "__main__":
    main()
