# -*- coding: utf-8 -*-
"""Takewrite starten — mit Projektauswahl.

Jedes Projekt bekommt einen eigenen Port. Das ist nicht nur Ordnung: Der
Browser trennt seinen Speicher nach Herkunft (Adresse **samt Port**), also hat
jedes Projekt damit von selbst seinen eigenen Arbeitsstand. Zwei Filme koennen
gleichzeitig offen sein, ohne sich ins Gehege zu kommen.

Die Projekte stehen in Projekte.txt:

    Der lange Sommer | D:\\Filme\\Der lange Sommer

Erste Zeile = Port 8794, zweite = 8795, und so weiter. Die Reihenfolge darf
darum spaeter nicht mehr geaendert werden — sonst sucht ein Projekt seinen
Stand am falschen Port. Neue Projekte immer unten anhaengen.
"""
import io, json, os, shutil, socket, subprocess, sys, webbrowser

# Die mitgelieferte Laufzeit ist eine eingebettete Python-Fassung: Ihr Suchpfad
# steht fest in Laufzeit/python314._pth, und der Ordner des laufenden Skripts
# kommt dabei NICHT dazu. Ohne diese Zeile findet der Starter sein eigenes
# Nachbarmodul lizenz nicht — und weil das Tor dann jeden abweist, startete das
# Kundenpaket bei niemandem. Auf dem Entwicklerrechner faellt das nie auf: Dort
# laeuft ein gewoehnliches Python, das seinen Skriptordner selbst mitbringt.
# server.py macht an seiner Stelle dasselbe.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def ausgabe_auf_utf8():
    """Steht bewusst NICHT beim Einlesen des Moduls: server.py bindet diese
       Datei ein und stellt seine Ausgabe selbst um. Zweimal umstellen nimmt
       dem ersten Wrapper den Puffer unter den Fuessen — danach ist stdout
       geschlossen und das naechste print bricht den Server ab."""
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)


HEIM      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LISTE     = os.path.join(HEIM, "Projekte.txt")
ALTE_DATEI = os.path.join(HEIM, "Projektordner.txt")
PROGRAMM  = os.path.join(HEIM, "Takewright.html")
PORT0     = 8794


# ---------------------------------------------------------------- Projektliste
def liste_lesen():
    projekte = []
    if os.path.exists(LISTE):
        for z in io.open(LISTE, encoding="utf-8"):
            z = z.strip()
            if not z or z.startswith("#"):
                continue
            name, _, pfad = z.partition("|")
            if pfad.strip():
                projekte.append((name.strip(), pfad.strip()))
    return projekte


# Ein stillgelegtes Projekt bleibt als Zeile stehen und traegt eine Tilde vor
# dem Namen. Der Grund ist die Portvergabe: Die Zeilennummer bestimmt den Port
# und der Port, wo der Arbeitsstand im Browser liegt. Wuerde man die Zeile
# wirklich entfernen, ruecken alle dahinter einen Port vor - und ihre Buecher
# haengen am falschen Film. Der Platz muss bleiben, auch wenn das Projekt geht.
STILLGELEGT = "~"


def ist_stillgelegt(name):
    return name.startswith(STILLGELEGT)


def klarname(name):
    return name[len(STILLGELEGT):].strip() if ist_stillgelegt(name) else name


def liste_schreiben(projekte):
    with io.open(LISTE, "w", encoding="utf-8", newline="\n") as f:
        f.write("# Die Projekte von Takewrite. Eine Zeile je Film:\n")
        f.write("#     Name | Ordner\n")
        f.write("# Die Reihenfolge bestimmt den Port (erste Zeile 8794, dann 8795 …)\n")
        f.write("# und damit, wo der Arbeitsstand liegt. Nie umsortieren, nur anhaengen.\n\n")
        for name, pfad in projekte:
            f.write("%s | %s\n" % (name, pfad))


def erstanlage():
    """Beim ersten Start aus der alten Projektordner.txt uebernehmen."""
    pfad = None
    if os.path.exists(ALTE_DATEI):
        for z in io.open(ALTE_DATEI, encoding="cp1252", errors="replace"):
            z = z.strip()
            if z and not z.startswith("#"):
                pfad = z
                break
    if not pfad:
        return []
    name = os.path.basename(pfad.rstrip("\\/")) or "Projekt 1"
    liste_schreiben([(name, pfad)])
    print("Projektliste angelegt aus Projektordner.txt: %s" % name)
    return [(name, pfad)]


# ---------------------------------------------------------------- Hilfsmittel
def lauscht(port):
    s = socket.socket()
    s.settimeout(0.4)
    try:
        s.connect(("127.0.0.1", port))
        return True
    except Exception:
        return False
    finally:
        s.close()


def python_pfad():
    """Erst die mitgelieferte Laufzeit, dann die des Entwicklers, dann das System."""
    for kandidat in (os.path.join(HEIM, "Laufzeit", "python.exe"),
                     r"G:\Python314\python.exe"):
        if os.path.exists(kandidat):
            return kandidat
    return sys.executable


def starten(name, pfad, port, oeffnen=True):
    """oeffnen=False, wenn der Aufrufer schon einen Browser vor sich hat:
       Legt man ein Projekt aus der App heraus an, faehrt der Server hoch,
       aber das Fenster wechselt die App selbst — ein zweites aufzureissen
       waere nur im Weg."""
    if not os.path.isdir(pfad):
        print("Diesen Ordner gibt es nicht: %s" % pfad)
        return False

    shutil.copy2(PROGRAMM, os.path.join(pfad, "Takewright.html"))
    # Der Steckbrief liegt beim Film — daran erkennt die App, welches Projekt
    # sie gerade ist, und schreibt den Namen in ihre Kopfzeile.
    io.open(os.path.join(pfad, "projekt.json"), "w", encoding="utf-8", newline="\n").write(
        json.dumps({"name": name, "ordner": pfad, "port": port}, ensure_ascii=False))

    if lauscht(port):
        print("Server läuft bereits auf Port %d." % port)
    else:
        subprocess.Popen(
            ["cmd", "/c", "start",
             "Takewrite-Server: %s  --  dieses Fenster beendet das Projekt" % name,
             "/min", python_pfad(),
             os.path.join(HEIM, "Werkzeuge", "server.py"), str(port), pfad],
            shell=False)
        print("Server gestartet auf Port %d." % port)

    if oeffnen:
        webbrowser.open("http://localhost:%d/Takewright.html" % port)
    return True


# ---------------------------------------------------------------- Bedienung
def neues_projekt(projekte):
    print()
    print("  Es geht ein Fenster auf — waehle den Ordner, in dem der Film liegt.")
    pfad = ordner_waehlen()
    if pfad is None:
        # Kein Dialog moeglich (kein PowerShell, kein Fenster): dann von Hand
        pfad = input("Ordner des Films (Pfad einfügen): ").strip().strip('"')
    elif not pfad:
        print("Abgebrochen.")
        return None
    pfad = pfad.strip().strip('"')
    if not pfad:
        return None
    if not os.path.isdir(pfad):
        print("Diesen Ordner gibt es nicht.")
        return None
    for _, p in projekte:
        if os.path.normcase(os.path.abspath(p)) == os.path.normcase(os.path.abspath(pfad)):
            print("Dieser Ordner steht schon in der Liste.")
            return None
    vorschlag = os.path.basename(pfad.rstrip("\\/"))
    name = input("Name des Projekts [%s]: " % vorschlag).strip() or vorschlag
    projekte.append((name, pfad))
    liste_schreiben(projekte)
    print("Angelegt: %s  (Port %d)" % (name, PORT0 + len(projekte) - 1))
    return len(projekte) - 1


# ------------------------------------------------------------- Verknuepfung
"""Eine Verknuepfung mit Symbol, angelegt beim ersten Start.

Eine fertige .lnk ins Paket zu legen geht nicht: Eine Windows-Verknuepfung
speichert den absoluten Zielpfad. Wer in einen eigenen Ordner entpackt
und wer auf den Desktop entpackt, braeuchte verschiedene Dateien. Angelegt wird sie darum
hier, wo die Pfade zur Laufzeit feststehen und immer stimmen.

Gebaut wird sie ueber den WScript.Shell von PowerShell — die mitgelieferte
Laufzeit ist ein nacktes Python ohne pywin32. Schlaegt es fehl, ist das kein
Grund, den Start abzubrechen: Die .bat funktioniert weiterhin.
"""
MARKE = os.path.join(HEIM, "Werkzeuge", ".verknuepfung")


def _ps(text):
    """Ein PowerShell-Zeichenkettenliteral. Pfade koennen Apostrophe enthalten."""
    return "'" + text.replace("'", "''") + "'"


def _powershell(befehl, zeit=25, sta=False):
    args = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass"]
    if sta:
        args.append("-STA")        # Fensterdialoge laufen nur im STA-Thread
    args += ["-Command", befehl]
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=zeit)
    except Exception:
        return None


def ordner_waehlen(titel="Ordner des Films wählen"):
    """Ein echter Ordner-Dialog statt eines eingefuegten Pfades.

    Einen Pfad in eine Konsole einzufuegen kann man niemandem zumuten, der
    diese App gekauft hat. Die mitgelieferte Laufzeit ist aber ein nacktes
    Python: kein tkinter, kein pywin32. Windows bringt den Dialog selbst mit,
    und PowerShell macht ihn auf — denselben Weg geht schon die Verknuepfung.

    Gibt None zurueck, wenn kein Dialog moeglich war (dann bleibt das Tippen),
    und "" wenn der Nutzer abgebrochen hat.
    """
    # Der Dialog braucht ein Fenster, das ihn besitzt. Ohne eines oeffnet er
    # sich zwar, bekommt aber kein Vordergrundrecht: Ruft ihn der Server auf —
    # ein Vorgang in einem minimierten Konsolenfenster —, liegt er unsichtbar
    # hinter allem, und der Nutzer sieht nur einen Knopf, der nicht mehr
    # zurueckkommt. Genau das ist am 29.08.2026 passiert. Ein winziges,
    # immer-oben-Fenster als Besitzer holt ihn nach vorn.
    befehl = ("Add-Type -AssemblyName System.Windows.Forms | Out-Null; "
              "Add-Type -AssemblyName System.Drawing | Out-Null; "
              "$o = New-Object System.Windows.Forms.Form; "
              "$o.TopMost = $true; $o.ShowInTaskbar = $false; "
              "$o.FormBorderStyle = 'None'; $o.Opacity = 0; "
              "$o.Size = New-Object System.Drawing.Size(1,1); "
              "$o.StartPosition = 'CenterScreen'; "
              "$o.Show(); $o.Activate(); "
              "$d = New-Object System.Windows.Forms.FolderBrowserDialog; "
              "$d.Description = %s; "
              "$d.ShowNewFolderButton = $false; "
              "$d.RootFolder = 'MyComputer'; "
              "$a = $d.ShowDialog($o); "
              "$o.Close(); "
              "if ($a -eq 'OK') { [Console]::Out.Write($d.SelectedPath) }") % _ps(titel)
    # Der Dialog wartet auf einen Menschen — die uebliche Frist von 25
    # Sekunden waere ein Abbruch mitten im Suchen. Laenger als anderthalb
    # Minuten soll aber niemand vor einem hakenden Knopf sitzen.
    e = _powershell(befehl, zeit=90, sta=True)
    if e is None or e.returncode != 0:
        return None
    return (e.stdout or "").strip()


def verknuepfung_bauen(wohin, ziel, symbol, ordner):
    befehl = ("$w = New-Object -ComObject WScript.Shell; "
              "$s = $w.CreateShortcut(%s); "
              "$s.TargetPath = %s; "
              "$s.WorkingDirectory = %s; "
              "$s.IconLocation = %s; "
              "$s.Description = 'Takewrite - Synchronbuecher am Bild schreiben'; "
              "$s.Save()"
              % (_ps(wohin), _ps(ziel), _ps(ordner), _ps(symbol)))
    _powershell(befehl)
    return os.path.exists(wohin)


def desktop_pfad():
    """Nicht ueber %USERPROFILE%: Bei OneDrive liegt der Desktop woanders."""
    e = _powershell("[Environment]::GetFolderPath('Desktop')")
    if not e or not e.stdout:
        return None
    pfad = e.stdout.strip()
    return pfad if pfad and os.path.isdir(pfad) else None


def desktop_name():
    """Wie die Verknuepfung auf dem Desktop heissen soll.

    Frueher hiess sie bei jeder Installation "Takewrite.lnk". Wer eine zweite
    Fassung auspackte — eine Testkopie, ein Kundenpaket zum Nachstellen —,
    ueberschrieb damit die Verknuepfung der ersten. Loeschte er den Testordner
    spaeter, zeigte die einzige Verknuepfung auf dem Desktop ins Leere, und die
    eigentliche Installation war nicht mehr zu finden. Genau das ist am
    02.09.2026 passiert.

    Die erste Installation behaelt den schlichten Namen; jede weitere haengt
    ihren Ordner an. So stehen sie nebeneinander und man sieht, welche welche
    ist."""
    d = desktop_pfad()
    schlicht = "Takewrite.lnk"
    if not d:
        return schlicht
    vorhanden = os.path.join(d, schlicht)
    if not os.path.exists(vorhanden):
        return schlicht
    try:                       # zeigt die vorhandene schon hierher? dann die
        roh = io.open(vorhanden, "rb").read()   # nicht verdoppeln
        if HEIM.encode("utf-16-le") in roh or HEIM.encode("latin-1") in roh:
            return schlicht
    except OSError:
        pass
    return "Takewrite (%s).lnk" % sicher_fuer_dateiname(os.path.basename(HEIM))


def sicher_fuer_dateiname(name):
    for c in '<>:"/\\|?*':
        name = name.replace(c, "-")
    return name.strip() or "Ordner"


def erstes_einrichten():
    """Laeuft genau einmal — beim ersten Start nach dem Entpacken."""
    if os.path.exists(MARKE):
        return
    bat = os.path.join(HEIM, "Takewrite starten.bat")
    symbol = os.path.join(HEIM, "Symbole", "takewright.ico")
    if not (os.path.exists(bat) and os.path.exists(symbol)):
        return

    print()
    print("  Einmalige Einrichtung")
    im_ordner = os.path.join(HEIM, "Takewrite.lnk")
    if verknuepfung_bauen(im_ordner, bat, symbol, HEIM):
        print("  Verknüpfung angelegt: %s" % im_ordner)
    else:
        print("  (Verknüpfung im Ordner ließ sich nicht anlegen — die .bat tut es auch.)")

    try:
        antwort = input("  Auch eine auf dem Desktop? [J/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return                      # ohne Marke: beim naechsten Mal neu fragen
    if antwort in ("", "j", "ja", "y"):
        d = desktop_pfad()
        if d and verknuepfung_bauen(os.path.join(d, desktop_name()), bat, symbol, HEIM):
            print("  Auf dem Desktop angelegt.")
        else:
            print("  (Auf dem Desktop ließ es sich nicht anlegen.)")

    try:
        io.open(MARKE, "w", encoding="utf-8").write("einmalig erledigt")
    except OSError:
        pass


def lizenz_tor():
    """Darf gearbeitet werden? Sonst der Weg zum Schein — und Schluss.

    Fehlt lizenz.py, wird ebenfalls nicht gestartet. Nicht weil das jemanden
    aufhielte, der den Ordner auseinandernimmt, sondern damit das Loeschen
    einer einzigen Datei nicht der bequemste Weg an der Pruefung vorbei ist."""
    try:
        import lizenz
    except Exception as e:
        print()
        print("  Takewrite ist unvollstaendig: %s" % e)
        print("  Bitte das Paket neu entpacken.")
        input("  Enter zum Schliessen ")
        return False

    s = lizenz.stand()
    if s["art"] == "schein":
        if s["rest"] <= 21:
            print()
            print("  Die Lizenz laeuft am %s ab — noch %d Tage."
                  % (s["bis"], s["rest"]))
            print("  Verlaengerung: %s" % lizenz.KONTAKT)
        return True

    if s["art"] == "schonfrist":
        print()
        print("  Herzlich willkommen — und Glückwunsch zum Erwerb von TAKEWRITE.")
        print()
        print("  Zum Freischalten sind es drei Handgriffe:")
        print()
        print("    1. Oben in der App auf das Lizenzfeld klicken.")
        print("    2. Den Code kopieren und an %s mailen." % lizenz.KONTAKT)
        print("    3. Du bekommst umgehend den Schlüssel zurück. Die Datei")
        print("       lizenz.dat in diesen Ordner legen — FERTIG!")
        print()
        print("       %s" % HEIM)
        print()
        print("  Bis dahin läuft Takewrite ohne Einschränkung: noch %d von %d Tagen."
              % (s["rest"], lizenz.SCHONFRIST))
        print()
        print("  Und jetzt viel Freude beim Schreiben mit TAKEWRITE.")
        return True

    print()
    print("  " + "=" * 60)
    print("  TAKEWRITE ist gesperrt")
    print("  " + "=" * 60)
    if s["art"] == "fremd":
        print()
        print("  Diese Lizenz gehoert zu einem anderen Rechner.")
        print("  Ein Schein gilt fuer einen Rechner. Bei einem Rechnerwechsel")
        print("  wird er umgeschrieben — das kostet nichts.")
    elif s["name"]:
        print()
        print("  Die Lizenz fuer %s ist am %s abgelaufen." % (s["name"], s["bis"]))
        print("  Verlaengerung: 189 Euro fuer das Folgejahr.")
    else:
        print()
        print("  Die Probezeit von %d Tagen ist vorbei." % lizenz.SCHONFRIST)
        print("  Die Arbeit ist nicht verloren: Buecher, Sicherungen und")
        print("  Einstellungen liegen unberuehrt in den Projektordnern.")
    print()
    print("  Rechnercode:  %s" % s["code"])
    print()
    print("  Diese Zeile an %s schicken:" % lizenz.KONTAKT)
    print()
    try:
        print("  " + lizenz.anforderung())
    except Exception:
        print("  (Rechnerkennung nicht lesbar — bitte einmal anrufen.)")
    print()
    print("  Die Antwort ist eine Datei 'lizenz.dat'. Die kommt in denselben")
    print("  Ordner wie 'Takewrite starten.bat', dann laeuft es wieder.")
    print()
    input("  Enter zum Schliessen ")
    return False


def probe():
    """Fuer den Paketbau: Laesst sich alles laden, was zum Start noetig ist?

    Absichtlich unabhaengig davon, WIE die Lizenzpruefung ausgeht — geprueft
    wird, ob sie ueberhaupt stattfinden kann. Sonst schluege der Bau eines
    Tages fehl, nur weil in einem Probeordner eine Probezeit abgelaufen ist."""
    import lizenz, server                                   # noqa: F401
    lizenz.stand()
    print("PROBE OK")
    return 0


def main():
    if "--probe" in sys.argv:
        return probe()
    ausgabe_auf_utf8()
    if not os.path.exists(PROGRAMM):
        print("Takewright.html fehlt in %s" % HEIM)
        input("Enter zum Schließen ")
        return

    if not lizenz_tor():
        return

    erstes_einrichten()

    projekte = liste_lesen() or erstanlage()

    if not projekte:
        print("Noch kein Projekt eingerichtet.")
        i = neues_projekt([])
        if i is None:
            input("Enter zum Schließen ")
            return
        projekte = liste_lesen()

    # Das Menue kommt auch bei einem einzigen Projekt — sonst waere "N" fuer
    # ein neues nie erreichbar. Enter startet einfach das erste.
    print()
    print("  TAKEWRITE — welches Projekt?")
    print("  " + "-" * 46)
    for i, (name, pfad) in enumerate(projekte):
        # Stillgelegte gar nicht erst zeigen: Wer sie weggenommen hat, will sie
        # nicht mehr sehen. Ihr Platz in der Datei bleibt trotzdem stehen —
        # er haelt die Ports der uebrigen fest. Die Nummern springen dadurch,
        # und das ist richtig so: Sie sind die Nummer in der Liste.
        if ist_stillgelegt(name):
            continue
        port = PORT0 + i
        marke = " ●" if lauscht(port) else "  "
        print("  %s %d)  %-28s  Port %d" % (marke, i + 1, name[:28], port))
    print("     N)  neues Projekt anlegen")
    print("  " + "-" * 46)
    print("     ● = läuft schon")
    print()

    wahl = input("Nummer (Enter = 1): ").strip().lower()
    if wahl in ("n", "neu"):
        i = neues_projekt(projekte)
        if i is None:
            input("Enter zum Schließen ")
            return
        projekte = liste_lesen()
    else:
        try:
            i = int(wahl) - 1 if wahl else 0
        except ValueError:
            i = 0
        if not (0 <= i < len(projekte)):
            i = 0

    name, pfad = projekte[i]
    if ist_stillgelegt(name):
        print()
        print("Dieses Projekt ist stillgelegt.")
        print("Zum Zurueckholen die Tilde vor dem Namen in Projekte.txt entfernen —")
        print("der Ordner und das Buch sind unberuehrt.")
        input("Enter zum Schließen ")
        return
    starten(name, pfad, PORT0 + i)


if __name__ == "__main__":
    main()
